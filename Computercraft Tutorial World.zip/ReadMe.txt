This world is prepared for use as a server world and can also be used in single player mode.
You MUST have:
Minecraft version 1.12.2 
Forge for version 1.12.2
The mods listed on page 12 of this PDF file https://github.com/Inksaver/StartComputercraftConsole/blob/master/Documentation/Computercraft%20Portable%20setup%201.12.2.pdf

For use in a server:
Set server.properties: level-name=Computercraft Tutorial
Save and start server

For single player:
Drop the world into your saves folder