--**********Toolkit**********
--http://pastebin.com/qxqdTqg8
--Last edited 13/03/2020 20:46
--
-- classes
function createCoordinatesObject(coordName)
	-- 0 = go south (z increases)
	-- 1 = go west  (x decreases)
	-- 2 = go north (z decreases
	-- 3 = go east  (x increases)

	-- compass[0] = "south"
	-- compass[1] = "west"
	-- compass[2] = "north"
	-- compass[3] = "east"
	
	clsCoord = {} -- the table representing the class, which will double as the metatable for any instances
	clsCoord.__index = clsCoord -- failed table lookups on the instances should fallback to the class table, to get methods

    local self = setmetatable({}, clsCoord)
    self.name = coordName
    self.x = 0
    self.y = 0
    self.z = 0
    self.facing = 0
    self.compass = "south"
		
	function clsCoord.getX(self)
		return self.x
	end
	function clsCoord.setX(self, newVal) -- setter
		self.x = newVal
	end
	function clsCoord.getY(self) -- getter
		return self.y
	end
	function clsCoord.setY(self, newVal)
		self.y = newVal
	end
	function clsCoord.getZ(self)
		return self.z
	end
	function clsCoord.setZ(self, newVal)
		self.z = newVal
	end
	function clsCoord.getFacing(self)
		return self.facing
	end
	function clsCoord.setFacing(self, newVal) -- setter
		self.facing = newVal
		if self.facing < 0 then
				self.facing = 3
		elseif self.facing > 3 then
				self.facing = 0
		end
		if self.facing == 0 then
			self.compass = "south"
		elseif self.facing == 1 then
			self.compass = "west"
		elseif self.facing == 2 then
			self.compass = "north"
		else
			self.compass = "east"
		end
	end
	function clsCoord.getCompass(self)
		return self.compass
	end
	function clsCoord.setCompass(self, newVal) -- setter
		self.compass = newVal

		if self.compass == "south" then
			self.facing = 0
		elseif self.compass == "west" then
			self.facing = 1
		elseif self.compass == "north" then
			self.facing = 2
		elseif self.compass == "east" then
			self.facing = 3
		end
	end
	function clsCoord.setAllValues(self, x, y, z, f)
		self.x = x
		self.y = y
		self.z = z
		clsCoord.setFacing(self, f)
	end
	function clsCoord.goUp(blocks)
		blocks = blocks or 1
		self.y = self.y + blocks
	end
	function clsCoord.goDown(blocks)
		blocks = blocks or 1
		self.y = self.y - blocks
	end
	--  uses:
	--	location:getX()  			get current turtle x coordinate
	--	location:getY()  			get current turtle y coordinate
	--	location:getZ()  			get current turtle z coordinate
	--	location:setX(xCoord)   	set current turtle x coordinate eg location:setX(-235)
	--	location:setY(yCoord)  		set current turtle y coordinate eg location:setY(66)
	--	location:setZ(zCoord) 		set current turtle z coordinate eg location:setZ(125)
	--	location:getFacing()    	returns a number 0 - 3 representing direction of player
	--	location:setFacing(facing) 	sets direction eg location:setFacing(1) (West)
	--	location:getCompass()  		returns direction as text eg "north"
	--	location:setCompass("X") 	sets direction using text eg location:setCompass("south")
	--	location:goUp(X)			increases Y coord by X
	--	location:goDown(X)			decreases Y coord by X
    return self
end

function createTurtleObject() 	
	clsTurtle = {} -- the table representing the class, which will double as the metatable for any instances
	clsTurtle.__index = clsTurtle -- failed table lookups on the instances should fallback to the class table, to get methods

    local self = setmetatable({}, clsTurtle)
    self.x = 0
    self.y = 0
    self.z = 0
    self.facing = 0
    self.compass = ""
	self.equippedLeft = ""
	self.equippedRight = ""
	self.placeSlot = 0
	self.placeItem = ""
	self.osVersion = os.version() -- eg CraftOS 1.8
	
	-- helper function for iterating lists
	function clsTurtle.values(self,t) -- general diy iterator
		local i = 0
		return function() i = i + 1; return t[i] end
	end
	-- logging methods
	function clsTurtle.getUseLog(self)
		return self.useLog
	end
	
	function clsTurtle.setUseLog(self, use)
		self.useLog = use
		return use
	end
	
	function clsTurtle.getLogExists(self)
		exists = false
		if fs.exists(self.logFileName) then
			exists = true
		end
		return exists
	end
	
	function clsTurtle.getLogFileName(self)
		return self.logFileName
	end
	function clsTurtle.setLogFileName(self, value)
		self.logFileName = value
	end
	function clsTurtle.getCurrentFileSize(self)		
		if self.logFileExists then
            return fs.getSize(self.logFileName)
        else
            return 0
        end
	end
	function clsTurtle.deleteLog(self)		
        if fs.exists(self.logFileName) then
            fs.delete(self.logFileName)
        end
        self.logFileExists = false
		
		return true
	end
	function clsTurtle.appendLine(self, newText)
        local handle = ""
        
        if fs.exists(self.logFileName) then --logFile already created
            handle = fs.open(self.logFileName, "a") 
        else
            handle = fs.open(self.logFileName, "w") --create file
        end
        self.logFileExists = true
        handle.writeLine(newText)
        handle.close()
	end
	
	function clsTurtle.saveToLog(self, text, toScreen)
		if toScreen == nil then
			toScreen = true
		end
		if text ~= "" and text ~= nil then
			if toScreen then
				print(text)
			end
			if self.useLog then
				clsTurtle.appendLine(self, text)
			end
		end
	end
	
	-- getters and setters
	function clsTurtle.getX(self) return self.x end
	function clsTurtle.setX(self, newVal) self.x = newVal end
	function clsTurtle.getY(self) return self.y end
	function clsTurtle.setY(self, newVal) self.y = newVal end
	function clsTurtle.getZ(self) return self.z end
	function clsTurtle.setZ(self, newVal) self.z = newVal end
	function clsTurtle.getFacing(self) return self.facing end
	function clsTurtle.setFacing(self, newVal)
		local direction = {"south","west","north","east"}
		self.facing = newVal
		if self.facing < 0 then
			self.facing = 3
		elseif self.facing > 3 then
			self.facing = 0
		end
		self.compass = direction[self.facing + 1]
	end
	function clsTurtle.getCompass(self) return self.compass end
	function clsTurtle.getPlaceItem(self) return self.placeItem end
	function clsTurtle.setPlaceItem(self, item, useDamage)
		local success = false
		local slot = clsTurtle.getItemSlot(self, item, useDamage)
		if slot > 0 then
			self.placeItem = item
		end
	end
	function clsTurtle.getEquipped(self, side)
		retValue = ""
		if side == "left" then
			retValue = self.equippedLeft
		else
			retValue = self.equippedRight
		end
		return retValue
	end
	function clsTurtle.setEquipped(self, side, value)
		if side == "left" then
			self.equippedLeft = value
		elseif side == "right" then
			self.equippedRight = value
		end
	end
	
	-- change direction and movement methods
	function clsTurtle.attack(self, direction)	
		direction = direction or "forward"
		local slot = turtle.getSelectedSlot()
		turtle.select(1)
		local success = false
		local attackLimit = 10 -- won't get in infinite loop attacking a minecart chest

		if direction == "up" then
			while turtle.attackUp() do --in case mob above
				sleep(1.5)
				attackLimit = attackLimit - 1
				if attackLimit <= 0 then
					break
				end			
			end
		elseif direction == "down" then
			while turtle.attackDown() do --in case mob below
				sleep(1.5)
				attackLimit = attackLimit - 1
				if attackLimit <= 0 then
					break
				end
			end
		else
			while turtle.attack() do --in case mob in front
				sleep(1.5)
				attackLimit = attackLimit - 1
				if attackLimit <= 0 then
					break
				end
			end
		end
		if attackLimit > 0 then
			success = true
		end
		turtle.select(slot)
		return success
	end
	
	function clsTurtle.back(self, steps)
		steps = steps or 1
		local success = false
		
		clsTurtle.refuel(self, steps)
		turtle.select(1)
		for i = 1, steps do
			if not turtle.back() then --cant move back
				clsTurtle.turnRight(self, 2) --face backward direction
				if clsTurtle.forward(self, 1) then-- will also attack mobs if in the way
					success = true
					clsTurtle.changeCoords(self, "back")
				end
				clsTurtle.turnRight(self, 2)
			end
		end
		
		return success
	end
	
	function clsTurtle.changeCoords(self, direction)
		--  0 = go south (z increases)
		--	1 = go west  (x decreases)
		--	2 = go north (z decreases
		--	3 = go east  (x increases)
		if direction == "forward" then
			if self.facing == 0 then
				self.z = self.z + 1 
			elseif self.facing == 1 then
				self.x = self.x - 1
			elseif self.facing == 2 then
				self.z = self.z - 1
			else
				self.x = self.x + 1
			end
		elseif direction == "back" then
			if self.facing == 0 then
				self.z = self.z - 1
			elseif self.facing == 1 then
				self.x = self.x + 1
			elseif self.facing == 2 then
				self.z = self.z + 1
			else
				self.x = self.x - 1
			end
		end
	end
	
	function clsTurtle.getCoords(self, fromFile)
		fromFile = fromFile or false
		--get world coordinates from player
		local coord = 0
		local response = ""
		local continue = true
		local event = ""
		local param1 = ""
		local getInput = true
		
		clsTurtle.clear(self)
		-- use built-in filesystem fs
		if fs.exists("homeCoords.txt") then --ask user if current coords are correct
			local fileHandle = fs.open("homeCoords.txt", "r")
			strText = fileHandle.readLine()
			self.x = tonumber(string.sub(strText, 3))
			strText = fileHandle.readLine()
			self.y = tonumber(string.sub(strText, 3))
			strText = fileHandle.readLine()
			self.z = tonumber(string.sub(strText, 3))
			strText = fileHandle.readLine()
			clsTurtle.setFacing(self, tonumber(string.sub(strText, 3)))
			fileHandle.close()
			clsTurtle.saveToLog(self, "Coordinates loaded from file:", false)
			clsTurtle.saveToLog(self, "x = "..self.x..", y = "..self.y..", z = "..self.z..", f = "..self.facing, false)
			print("Coordinates loaded from file:\n")
			print("XYZ: - "..self.x.." / "..self.y.." / "..self.z.."\n")
			print("Facing: "..self.compass)
			print("\nUse F3 to check these coordinates")
			write("\nAre they correct (y/n + Enter)?")
			response = read()
			if response == "y" or response == "" then
				getInput = false
			else
				clsTurtle.clear(self)
			end
		end
		if getInput then
			print("IMPORTANT! Stand directly behind turtle")
			print("Press F3 to read coordinates")
			print()
			continue = true
			while continue do
				print("Please enter your X coordinate")
				write("  x = ")
				coord = nil
				while coord == nil do
					coord = tonumber(read())
					if coord == nil then
						clsTurtle.clear(self)
						print("Incorrect input. Use numbers only!")
						print()
						print("Please enter your X coordinate")
						write("  x = ")
					end
				end
				self.x = coord
				clsTurtle.clear(self)
				print("Please enter your Y coordinate")
				write("  y = ")
				coord = nil
				while coord == nil do
					coord = tonumber(read())
					if coord == nil then
						clsTurtle.clear(self)
						print("Incorrect input. Use numbers only")
						print()
						print("Please enter your y coordinate")
						write("  y = ")
					end
				end
				self.y = coord
				clsTurtle.clear(self)
				print("Please enter your Z coordinate")
				write("  z = ")
				coord = nil
				while coord == nil do
					coord = tonumber(read())
					if coord == nil then
						clsTurtle.clear(self)
						print("Incorrect input. Use numbers only")
						print()
						print("Please enter your z coordinate")
						write("  z = ")
					end
				end
				self.z = coord
				response = true
				while response do
					response = false
					clsTurtle.clear(self)
					print("Enter Direction you are facing:")
					print("  0,1,2,3 (s,w,n,e)")
					print()
					print(  "  Direction = ")
					event, param1 = os.pullEvent ("char")
					if param1 == "s" or param1 == "S" then
						coord = 0
					elseif param1 == "w" or param1 == "W" then
						coord = 1
					elseif param1 == "n" or param1 == "N" then
						coord = 2
					elseif param1 == "e" or param1 == "E" then
						coord = 3
					elseif param1 == "0" or param1 == "1" or param1 == "2" or param1 == "3" then
						coord = tonumber(param1)
					else
						print()
						print("Incorrect input: "..param1)
						print()
						print("Use 0,1,2,3,n,s,w,e")
						sleep(2)
						response = true
					end
				end
				clsTurtle.setFacing(self, coord)
				clsTurtle.clear(self)
				print("Your current location is:")
				print()
				print("  x = "..self.x)
				print("  y = "..self.y)
				print("  z = "..self.z)
				print("  facing "..self.compass.." ("..self.facing..")")
				print()
				write("Is this correct? (y/n)")
				event, param1 = os.pullEvent ("char")
				if param1 == "y" or param1 == "Y" then
					continue = false
				end
			end
			-- correct coords to compensate for player standing position
			-- First tree is considered as point zero, on startup, turtle is in front of this tree
			-- Player is behind turtle, use 2 blocks to compensate
			-- facing:		Change:
			-- 0 (S)		z+1
			-- 1 (W)		x-1
			-- 2 (N)		z-1
			-- 3 (E)		x+1
			if self.facing == 0 then
				self.z = self.z + 2
			elseif self.facing == 1 then
				self.x = self.x - 2
			elseif self.facing == 2 then
				self.z = self.z - 2
			elseif self.facing == 3 then
				self.x = self.x + 2
			end
			
			-- create/overwrite 'homeCoords.txt'
			local fileHandle = fs.open("homeCoords.txt", "w")
			fileHandle.writeLine("x="..self.x)
			fileHandle.writeLine("y="..self.y)
			fileHandle.writeLine("z="..self.z)
			fileHandle.writeLine("f="..self.facing)
			fileHandle.close()
			clsTurtle.saveToLog(self, "homeCoords.txt file created", true)
			clsTurtle.saveToLog(self, "x = "..T:getX()..", y = "..T:getY()..", z = "..T:getZ()..", f = "..T:getFacing(), false)
		end
	end

	function clsTurtle.down(self, steps, checkDungeon)
		steps = steps or 1
		if checkDungeon == nil then
			checkDungeon = false
		end
		local success = false
		
		clsTurtle.refuel(self, steps)
		turtle.select(1)
		for i = 1, steps do
			if turtle.detectDown() then -- block below
				if checkDungeon then
					if clsTurtle.isDungeon(self, "down") then
						clsTurtle.writeCoords(self, "DungeonCoords.txt")
						print("Mossy cobblestone found")
						error()
					end
				end
				if clsTurtle.getBlockType(self, "down") == "minecraft:bedrock" then
					break
				else
					turtle.digDown()
				end 
			end
			if turtle.down() then --move down unless mob in the way
				success = true
			else -- not bedrock, could be mob or minecart
				if clsTurtle.attack(self, "down") then -- attack succeeded
					if turtle.down() then
						success = true
					end
				end
			end
			if success then
				self.y = self.y - 1
			end
		end
		
		return success
	end
	
	function clsTurtle.forward(self, steps, checkDungeon)    
		steps = steps or 1
		if checkDungeon == nil then
			checkDungeon = false
		end
		local result, data
		local success = true
		local retryMove = 10
		
		clsTurtle.refuel(self, steps)
		turtle.select(1)
		for i = 1, steps do
			while turtle.detect() do -- allow for sand/gravel falling
				if checkDungeon then
					if clsTurtle.isDungeon(self, "forward") then
						clsTurtle.writeCoords(self, "DungeonCoords.txt")
						print("Mossy cobblestone found")
						error()
					end
				end
				if not clsTurtle.dig(self, "forward") then-- cannot dig. either bedrock or in server protected area
					success = false
					if clsTurtle.getBlockType(self, "forward") == "minecraft:bedrock" then
						print("Bedrock in front:function exit")
					end
					break
				end
			end
			success = false
			if turtle.forward() then
				success = true
			else
				if self.mobAttack then
					if clsTurtle.attack(self, "forward") then
						if turtle.forward() then
							success = true
						end
					else				
						result, data = turtle.forward()
						print(data..":function exit")
						break
					end
				else
					while not turtle.forward() do
						clsTurtle.saveToLog(self, "Waiting for mob to leave...", true)
						sleep(5)
						retryMove = retryMove - 1
						if retryMove <= 0 then
							break
						end
					end
					if retryMove  <= 0 then 
						if clsTurtle.attack(self, "forward") then
							if turtle.forward() then
								success = true
							end
						else				
							result, data = turtle.forward()
							print(data..":function exit")
							break
						end
					end
				end
			end
			if success then
				clsTurtle.changeCoords(self, "forward")
			end
		end
		return success
	end
	
	function clsTurtle.turnLeft(self, steps)
		steps = steps or 1
		for i = 1, steps do
			turtle.turnLeft()
			self.facing = self.facing - 1
			if self.facing < 0 then
				self.facing = 3
			end
		end
	end

	function clsTurtle.turnRight(self, steps)
		steps = steps or 1
		for i = 1, steps do
			turtle.turnRight()
			self.facing = self.facing + 1
			if self.facing > 3 then
				self.facing = 0
			end
		end
	end
	
	function clsTurtle.up(self, steps, checkDungeon)
		steps = steps or 1
		if checkDungeon == nil then
			checkDungeon = false
		end
		local success = false
		clsTurtle.refuel(self, steps)
		turtle.select(1)

		for i = 1, steps do
			if turtle.detectUp() then -- block above
				if checkDungeon then
					if clsTurtle.isDungeon(self, "up") then
						clsTurtle.writeCoords(self, "DungeonCoords.txt")
						print("Mossy cobblestone found")
						error()
					end
				end
				if clsTurtle.getBlockType(self, "up") == "minecraft:bedrock" then
					print("Bedrock above:function exit")
					break
				else
					clsTurtle.dig(self, "up")
				end
			end
			if turtle.up() then  --move up unless mob in the way
				success = true
			else
				if clsTurtle.attack(self, "up") then -- attack succeeded
					if turtle.up() then
						success = true
					end
				end
			end
			if success then
				self.y = self.y + 1
			end
		end
		return success
	end
	-- other methods
	function clsTurtle.checkInventoryForItem(self, items, quantity, required)
		if required == nil then
			required = true
		end
		local isLog = false
		local isStone = false
		local userChoice = false
		local damage = 0
		for i = 1, #items do
			if items[i] == "minecraft:log" then
				isLog = true
			end
			if items[i] == "minecraft:stone" then
				isStone = true
			end
			if items[i] == "userChoice" then
				userChoice = true
			end
		end
		-- item = {"minecraft:planks", "minecraft:log", "mineraft:lava_bucket"} 
		-- quantity = {4, 1, 1}
		local retValue = ""
		local event = ""
		local param1 = ""
		local numOnboard = 0
		local waiting = true
		local index = 0
		-- allow 1 user choice of block
		while waiting do
			if userChoice then
				index = 1
				numOnboard = 0
				print("Add your choice of block to any slot")
				for i = 1, 16 do
					if turtle.getItemCount(i) > 0 then
						numOnboard, retValue, damage = clsTurtle.getSlotContains(self, i)
						
						break
					end
				end
			else
				index, retValue, numOnboard = clsTurtle.checkInventory(self, items, quantity, required, isLog, isStone)
			end
			if numOnboard >= quantity[index] then
				break
			else
				event, param1 = os.pullEvent ()
				if event == "turtle_inventory" then
					if userChoice then
						-- find first item on board
						for i = 1, 16 do
							if turtle.getItemCount(i) > 0 then
								numOnboard, retValue, damage = clsTurtle.getSlotContains(self, i)
								break
							end
						end
					else
						index, retValue, numOnboard = clsTurtle.checkInventory(self, items, quantity, required, isLog, isStone)
						-- check for log2
						if numOnboard >= quantity[index] then
							break
						end
					end
				elseif event == "key"  and not required then
					if param1 == keys.enter then
						break
					end
				end
			end
		end
		if retValue ~= "" then
			if retValue == "minecraft:lava_bucket" then
				clsTurtle.refuel(self, 0)
				clsTurtle.dropItem(self, "minecraft:bucket", 0, "up")
			else
				print(retValue.." accepted with thanks")
			end
			sleep(1.5)
		end
		return retValue
	end
	
	function clsTurtle.checkInventory(self, items, quantity, required, isLog, isStone)
		-- items are a list of related items eg lava_bucket, coal, planks
		-- quantity is a matching list of quantities eg 1, 13, 64(1000 fuel)
		local gotItemSlot = 0
		local damage = 0
		local count = 0
		local retValue = ""
		local index = 0
		clsTurtle.clear(self)
		for i = 1, #items do
			index = i
			gotItemSlot, damage, count = clsTurtle.getItemSlot(self, items[i]) -- 0 if not present return slot, damage, total
			if gotItemSlot > 0 then --an item has been found, quantity is total onboard
				if count >= quantity[i] then
					retValue = items[i]
					break
				end
			else
				if isLog then
					gotItemSlot, damage, count = clsTurtle.getItemSlot(self, "minecraft:log2") -- 0 if not present return slot, damage, total
					if gotItemSlot > 0 then
						retValue = "minecraft:log2"
						break
					end
				end
			end
			if i == 1 then
				if isStone then
					print("Add "..quantity[1] - count.." granite / andesite / diorite")
					print("(polished preferred) to any slot")
				else
					print("Add "..quantity[1] - count.." "..items[1].." to any slot(s) ")
				end
			else
				print("Or add "..quantity[i] - count.." "..items[i].." to any slot(s) ")
			end
			if not required then
				print("(This item is not required)\n")
				if i == #items then
					print("Hit Enter to continue..")
				end
			end
			
		end
		return index, retValue, count
	end
	
	function clsTurtle.clear(self)
		term.clear()
		term.setCursorPos(1,1)
	end
	
	function clsTurtle.craft(self, item, quantity)	
		local slot = turtle.getSelectedSlot()
		local craftOK = false
		local chestSlot = 0
		local holeSlot = 0
		local sourceSlot = 0
		local turns = 0
		local doContinue = true
		
		chestSlot = clsTurtle.getItemSlot(self, "minecraft:chest") --get the slot number containing a chest
		if chestSlot == 0 then -- chest not found
            -- digDown, drop all items into hole, then re-equip later
			holeSlot = clsTurtle.getFirstEmptySlot(self)
			turtle.select(holeSlot)
			turtle.digDown()
			turtle.dropDown()
		end
		if item == "minecraft:planks" then
			sourceSlot = clsTurtle.getItemSlot(self,"minecraft:log") --get the slot number containing 1 or more logs
			if sourceSlot == 0 then
				sourceSlot = clsTurtle.getItemSlot(self,"minecraft:log2") --get the slot number containing 1 or more logs2
				if sourceSlot == 0 then
					doContinue = false
				end
			end
		elseif item == "minecraft:chest" then
			sourceSlot = clsTurtle.getItemSlot(self, "minecraft:planks") --get the slot number containing planks
		elseif item == "minecraft:stone_stairs" then
			sourceSlot = clsTurtle.getItemSlot(self, "minecraft:cobblestone") --get the slot number containing cobble
		end
		if doContinue then
			if chestSlot > 0 then
				while turtle.detect() do --check for clear space to place chest
					clsTurtle.turnRight(self, 1)
					turns = turns + 1
					if turns == 4 then
						turns = 0
						break
					end
				end

				turtle.select(1)
				while turtle.detect() do --clear space in front. Use loop in case of sand/gravel falling
					turtle.dig()
					sleep(.5)
				end
				turtle.select(chestSlot) --should be slot with chest
				while not turtle.place() do
					clsTurtle.attack(self)
				end
			end
			-- fill chest with everything except required items
			for i = 1, 16 do
				if i ~= sourceSlot then
					turtle.select(i)
					if chestSlot > 0 then
						turtle.drop()
					else
						turtle.dropDown()
					end
				end
			end

			turtle.select(sourceSlot)
			turtle.transferTo(16) --move crafting item to 16
			--ready to craft
			turtle.select(16)
			if item == "minecraft:planks" then -- crafting planks
				turtle.transferTo(1, quantity / 4)
				turtle.select(16)
				if chestSlot > 0 then --drop remaining resources before crafting
					turtle.drop()
				else
					turtle.dropDown()
				end
			elseif item == "minecraft:chest" then  --T:craft("minecraft:chest", 1)
				--8 planks = 1 chest 
				turtle.transferTo(1, 1)
				turtle.transferTo(2, 1)
				turtle.transferTo(3, 1)
				turtle.transferTo(5, 1)
				turtle.transferTo(7, 1)
				turtle.transferTo(9, 1)
				turtle.transferTo(10, 1)
				turtle.transferTo(11, 1)
			elseif item == "minecraft:stone_stairs" then  --T:craft("minecraft:stone_stairs", 40)
				--6 cobblestone = 4 stairs
				turtle.transferTo(1, quantity / 4)
				turtle.transferTo(5, quantity / 4)
				turtle.transferTo(6, quantity / 4)
				turtle.transferTo(9, quantity / 4)
				turtle.transferTo(10, quantity / 4)
				turtle.transferTo(11, quantity / 4)
			end
			-- Attempt to craft item into slot 16
			turtle.select(16)
			if chestSlot > 0 then
				turtle.drop()
			else
				turtle.dropDown()
			end
			if turtle.craft() then
				craftOK = true
				--now put crafted item in chest first, so will mix with any existing similar items
				if chestSlot > 0 then
					turtle.drop()
				end
			else --crafting not successful, so empty out all items into chest
				for i = 1, 16 do
					if turtle.getItemCount(i) > 0 then
						turtle.select(i)
						if chestSlot > 0 then
							turtle.drop()
						else
							turtle.dropDown()
						end
					end
				end
			end
			turtle.select(1) --empty chest into slot 1 onwards
			if chestSlot > 0 then
				while turtle.suck() do end
				turtle.dig() -- collect chest
				if turns > 0 then --return to original position
					clsTurtle.turnLeft(self,turns)
				end
			else
				while turtle.suckUp() do end
				while turtle.suckDown() do end
				for i = 1, 4 do
					while turtle.suck() do end
					clsTurtle.turnRight(self, 1)
				end
				clsTurtle.place(self, "minecraft:dirt", -1, "down")
			end
		end
		
		turtle.select(slot)
		return craftOK
	end
	
	function clsTurtle.createTunnel(self, length, allowAbandon, checkDungeon)
		if checkDungeon == nil then
			checkDungeon = true
		end
		-- clsTurtle.go(self, path, useTorch, torchInterval, leaveExisting, checkDungeon)
		-- assume at floor level at start
		local leaveExisting = true
		local useTorch = false
		local distance  = 1
		local blockAbove = ""
		local aboveType = 0
		local blockBelow = ""
		local belowType = 0
		local waterCountAbove = 0
		local waterCountBelow = 0
		local onGround = true
		for i = 1, length do
			if onGround then -- 1, 3, 5, 7 etc
				blockBelow, belowType = clsTurtle.getBlockType(self, "down")
				if blockBelow == "minecraft:lava" then
					clsTurtle.go(self, "C2L1C1R2C1L1", useTorch, 0, leaveExisting, checkDungeon)
				elseif blockBelow == "minecraft:water" then
					clsTurtle.go(self, "C2", useTorch, 0, leaveExisting, checkDungeon)
					waterCountBelow = waterCountBelow + 1
				else
					clsTurtle.go(self, "C2", useTorch, 0, leaveExisting, checkDungeon)
				end
				clsTurtle.up(self, 1, checkDungeon)
				onGround = false
				blockAbove, aboveType = clsTurtle.getBlockType(self, "up")
				if blockAbove == "minecraft:lava" then
					clsTurtle.go(self, "C0L1C1R2C1L1", useTorch, 0, leaveExisting, checkDungeon)
				elseif blockAbove == "minecraft:water" then
					clsTurtle.go(self, "C0L1C1R2C1L1", useTorch, 0, leaveExisting, checkDungeon)
					waterCountAbove = waterCountAbove + 1
				else
					clsTurtle.go(self, "C0", useTorch, 0, leaveExisting, checkDungeon)
				end
				-- if on first block check behind
				if i == 1 then
					clsTurtle.go(self, "R2C1R2", useTorch, 0, leaveExisting, checkDungeon)
				end
				if distance >= 8 then
					if distance % 8 == 0 then -- 8th or other position
						clsTurtle.go(self, "t5", useTorch, 0, false, checkDungeon)
					end
				end
			else -- at ceiling 2, 4, 6, 8 etc
				blockAbove, aboveType = clsTurtle.getBlockType(self, "up")
				if blockAbove == "minecraft:lava" then
					clsTurtle.go(self, "C0L1C1R2C1L1", useTorch, 0, leaveExisting, checkDungeon)
				elseif blockAbove == "minecraft:water" then
					clsTurtle.go(self, "C0L1C1R2C1L1", useTorch, 0, leaveExisting, checkDungeon)
					waterCountAbove = waterCountAbove + 1
				else
					clsTurtle.go(self, "C0", useTorch, 0, leaveExisting, checkDungeon)
				end
				if distance == 2 then
					clsTurtle.go(self, "t1", useTorch, 0, false, checkDungeon)
				end
				clsTurtle.down(self, 1, checkDungeon)
				onGround = true
				blockBelow, belowType = clsTurtle.getBlockType(self, "down")
				if blockBelow == "minecraft:lava" then
					clsTurtle.go(self, "C2L1C1R2C1L1", useTorch, 0, leaveExisting, checkDungeon)
				elseif blockBelow == "minecraft:water" then
					clsTurtle.go(self, "C2", useTorch, 0, leaveExisting, checkDungeon)
					waterCountBelow = waterCountBelow + 1
				else
					clsTurtle.go(self, "C2", useTorch, 0, leaveExisting, checkDungeon)
				end
			end
			-- now move forward if length > 1
			if length > 1 then
				if i < length then -- not on last iteration
					clsTurtle.forward(self,1, checkDungeon)
					distance = distance + 1
				else -- on last iteration
					if not onGround then
						clsTurtle.go(self, "C1", useTorch, 0, leaveExisting, checkDungeon)
						clsTurtle.down(self, 1, checkDungeon)
						onGround = true
					end
				end
			else -- one unit only so move down
				clsTurtle.down(self, 1, checkDungeon)
				onGround = true
			end
			
			if allowAbandon then
				if waterCountAbove + waterCountBelow >= 6 then
					if not onGround then
						clsTurtle.down(self, 1, checkDungeon)
						onGround = true
					end
					break
				end
			end
		end
		
		return distance -- 1 to length. cut short if 3 or more water
	end
	
	function clsTurtle.detect(self, direction)
		direction = direction or "forward"
		result = false
		if direction == "forward" then
			result = turtle.detect()
		elseif direction == "up" then
			result = turtle.detectUp()
		else -- down
			result = turtle.detectDown()
		end
		return result
	end
	
	function clsTurtle.dig(self, direction)
		direction = direction or "forward"
		local success = false
		turtle.select(1)
		if direction == "up" then
			while turtle.digUp() do
				sleep(0.7)
				success = true
			end
		elseif direction == "down" then
			if turtle.digDown() then
				success = true
			end
		else -- forward by default
			while turtle.dig() do
				sleep(0.7)
				success = true
			end
		end
		return success
	end
	
	function clsTurtle.drop(self, slot, direction, amount)
		direction = direction or "forward"
		turtle.select(slot)
		local success = false
		if direction == "up" then
			if amount == nil then
				if turtle.dropUp() then
					success = true
				end
			else
				if turtle.dropUp(amount) then
					success = true
				end
			end
		elseif direction == "down" then
			if amount == nil then
				if turtle.dropDown() then
					success = true
				end
			else
				if turtle.dropDown(amount) then
					success = true
				end
			end
		else
			if amount == nil then
				if turtle.drop() then
					success = true
				end
			else
				if turtle.drop(amount) then
					success = true
				end
			end
		end
		return success
	end
	
	function clsTurtle.dropItem(self, item, keepAmount, direction)
		keepAmount = keepAmount or 0
		direction = direction or "down"
		local itemSlot = 0
		local stockData = {}
		
		if keepAmount <= 0 then -- drop everything
			itemSlot = clsTurtle.getItemSlot(self, item)
			while itemSlot > 0 do
				clsTurtle.drop(self, itemSlot, direction)
				itemSlot = clsTurtle.getItemSlot(self, item)
			end
		elseif keepAmount >= 64 then -- drop everything else
			stockData = clsTurtle.getStock(self, item)
			if item == "minecraft:log" then
				if stockData.mostSlot ~= stockData.leastSlot then
					clsTurtle.drop(self, stockData.leastSlot, direction)
				end
			else
				while stockData.total > keepAmount do
					if stockData.mostSlot ~= stockData.leastSlot then
						clsTurtle.drop(self, stockData.leastSlot, direction)
					else --only one slot but more than required in it
						clsTurtle.drop(self, stockData.mostSlot, direction)
					end
					stockData = clsTurtle.getStock(self, item)
				end
			end
		else --store specific amount
			itemSlot = clsTurtle.getItemSlot(self, item)
			local dropCount = turtle.getItemCount(itemSlot) - keepAmount
			if itemSlot > 0 then
				clsTurtle.drop(self, itemSlot, direction, dropCount)
			end
		end
	end
	
	function clsTurtle.dumpRefuse(self, keepCobbleStacks)
		--dump dirt, cobble, sand, gravel
		keepCobbleStacks = keepCobbleStacks or 0
		local itemlist = {}
		local blockType = ""
		local blockModifier
		local slotCount
		local cobbleCount = 0
		local dirtCount = 0

		itemlist[1] = "minecraft:gravel"
		itemlist[2] = "minecraft:stone"
		itemlist[3] = "minecraft:sand"
		itemlist[4] = "minecraft:flint"
		for x = 1, 15 do -- sort inventory
			for i = x + 1 , 16 do
				if turtle.getItemCount(i) > 0 then
					turtle.select(i)
					if turtle.compareTo(x) then
						turtle.transferTo(x)
					end
				end
			end
		end
		for i = 1, 16 do
			slotCount, blockType, blockModifier = clsTurtle.getSlotContains(self,i)
			
			if blockType == "minecraft:cobblestone" then
				if cobbleCount > keepCobbleStacks then
					turtle.select(i)
					turtle.drop()
				else
					cobbleCount = cobbleCount + 1
				end
			end
			if blockType == "minecraft:dirt" then
				if dirtCount > 0 then
					turtle.select(i)
					turtle.drop()
				else
					dirtCount = dirtCount + 1
				end
			end
			for j = 1, #itemlist do
				if blockType == itemlist[j] then
					turtle.select(i)
					turtle.drop()
					break
				end
			end
		end
		turtle.select(1)
	end
	
	function clsTurtle.emptyTrash(self, direction)
		direction = direction or "down"
		local slotData = {}
		local item = ""
		local move = false
		local keepItems = {"minecraft:cobblestone", "minecraft:redstone", "minecraft:sand", "minecraft:planks",
							"minecraft:chest", "minecraft:log", "minecraft:log2", "minecraft:iron_ore", "minecraft:reeds", "minecraft:sapling",
							"minecraft:bucket", "minecraft:lava_bucket", "minecraft:water_bucket", "minecraft:torch", "minecraft:diamond",
							"minecraft:coal", "minecraft:iron_ingot"}
							
		local keepit = false					
		-- empty excess cobble, dirt, all gravel, unknown minerals
		--keep max of 1 stack
		clsTurtle.sortInventory(self)
		if direction == "down" then
			if clsTurtle.down(self, 1) then
				move = true
			end
		end
		for i = 1, 16 do
			keepit = false
			if turtle.getItemCount(i) > 0 then
				item = clsTurtle.getItemName(self, i)
				for _,v in pairs(keepItems) do
					if v == item then
						keepit = true
						break
					end
				end
				if not keepit then
					--clsTurtle.saveToLog(self, "EmptyTrash():Dropping "..item, true)
					turtle.select(i)
					turtle.dropDown()
				end
			end
		end
		clsTurtle.sortInventory(self)
		clsTurtle.emptyTrashItem(self, "down", "minecraft:cobblestone", 128)
		clsTurtle.emptyTrashItem(self, "down", "minecraft:redstone", 64)
		slotData = clsTurtle.getStock(self, "minecraft:coal", 0)
		if slotData.total > 64 then
			if slotData.mostSlot ~= slotData.leastSlot and slotData.leastSlot ~= 0 then
				turtle.select(slotData.leastSlot)
				turtle.refuel()
				--clsTurtle.saveToLog(self, "EmptyTrash():xs coal used for fuel", true)
			end
		end
		if direction == "down" and move then
			clsTurtle.up(self, 1)
		end
		turtle.select(1)
	end
	
	function clsTurtle.emptyTrashItem(self, direction, item, maxAmount)
		local stockData = clsTurtle.getStock(self, item)
		
		while stockData.total > maxAmount and stockData.mostSlot > 0 do
			turtle.select(stockData.mostSlot)
			if direction == "up" then
				if not turtle.dropUp() then
					if not turtle.dropDown() then
						--clsTurtle.saveToLog(self, "EmptyTrashItem():error ", true)
						break
					end
				end
			else
				if not turtle.dropDown() then
					if not turtle.dropUp() then
						--clsTurtle.saveToLog(self, "EmptyTrashItem():error ", true)
						break
					end
				end
			end
			stockData = clsTurtle.getStock(self, item)
		end
	end
	
	function clsTurtle.equip(self, side, useItem, useDamage)
		useDamage = useDamage or 0
		local slot, damage = clsTurtle.getItemSlot(self, useItem)
		local currentSlot = turtle.getSelectedSlot()
		local success = false
		--[[
		minecraft:crafting_table
		minecraft:diamond_pickaxe
		minecraft:diamond_sword
		minecraft:diamond_shovel
		minecraft:diamond_hoe
		minecraft:diamond_axe
		wireless modem = ComputerCraft:CC-Peripheral, damage = 1
		]]
		
		if slot > 0 and damage == useDamage then
			turtle.select(slot)
			if side == "right" then
				if turtle.equipRight() then
					success = true
					self.equippedRight = useItem
				end
			else
				if turtle.equipLeft() then
					success = true
					self.equippedLeft = useItem
				end
			end
		end
		turtle.select(currentSlot)
		
		return success
	end
	
	function clsTurtle.findBedrockTop(self, height)
		local bedrockFound = false
		repeat
			bedrockFound = false
			clsTurtle.clear(self)
			print("Checking surrounding  blocks...")
			for i = 1, 4 do
				clsTurtle.turnLeft(self, 1)
				if clsTurtle.getBlockType(self, "forward") == "minecraft:bedrock" then
					bedrockFound = true
					print("Bedrock found...")
				end
			end
			if bedrockFound then
				clsTurtle.up(self, 1)
				height = height -1 
				clsTurtle.place(self, "minecraft:cobblestone", 0, "down")
				print("Moving up...")
			end
		until not bedrockFound
		repeat
			bedrockFound = false
			local moved = 0
			for i = 1, 5 do
				if clsTurtle.forward(self, 1) then
					moved = moved + 1
					for i = 1, 4 do
						clsTurtle.turnLeft(self, 1)
						if clsTurtle.getBlockType(self, "forward") == "minecraft:bedrock" then
							bedrockFound = true
							print("Bedrock found: not continuing this row")
						end
					end
					if bedrockFound then
						break
					end
				else -- hit bedrock
					print("Hit bedrock in front")
					bedrockFound = true
					break
				end
			end
			clsTurtle.turnLeft(self, 2)
			for i = 1, moved do
				clsTurtle.go(self, "C2F1")
			end
			clsTurtle.go(self, "L2C1")
			if bedrockFound then
				print("Moving up...")
				clsTurtle.go(self, "U1C2")
				height = height -1
			else
				print("Area clear of bedrock...")
			end
		until bedrockFound == false
		return height
	end
	
	function clsTurtle.getBlockType(self, direction)
		-- turtle.inspect() returns two values
		-- 1) boolean (true/false) success
		-- 2) table with two values:
		--	.name (string) e.g. "minecraft:log"
		--	.metadata (integer) e.g. 0
		--	oak has metadata of 0, spruce 1, birch 2 etc
		local blockType = nil
		local blockModifier = nil
		local success = false
		local data = {} --initialise empty table variable
	 
		if direction == "up" then
			success, data = turtle.inspectUp() -- store information about the block above in a table	
		elseif direction == "down" then
			success, data = turtle.inspectDown() -- store information about the block below in a table
		else
			success, data = turtle.inspect() -- store information about the block ahead in a table
		end
		if success then -- block found
			blockType = data.name -- eg "minecraft:log"
			blockModifier = data.metadata
		end
		
		return blockType, blockModifier
	end
	
    function clsTurtle.getFirstEmptySlot(self)
        local iSlot = 0
        for i = 1,16 do
            if turtle.getItemCount(i) == 0 then
                iSlot = i
                break
            end
        end
        return iSlot
    end
    
	function clsTurtle.getItemCount(self, item, modifier)
		local slot, damage, total, slotData = clsTurtle.getItemSlot(self, item, modifier) --return .leastSlot, .leastModifier, total, slotData
		return total
	end
	
	function clsTurtle.getItemName(self, slot)
		local data = {} --initialise empty table variable
		data.name = ""
		
		if turtle.getItemCount(slot) > 0 then
			data = turtle.getItemDetail(slot)
		end
		
		return data.name
	end
	
	function clsTurtle.getItemSlot(self, item, useDamage)
		-- return slot no with least count, damage(modifier) and total count available
		-- along with a table of mostSlot, mostCount, leastSlot, leastCount
		useDamage = useDamage or -1 -- -1 damage means is not relevant
		local data = {} --initialise empty table variable
		local slotData = {}
		local total = 0
		-- setup return table
		slotData.mostSlot = 0
		slotData.mostName = ""
		slotData.mostCount = 0
		slotData.mostModifier = 0
		slotData.leastSlot = 0
		slotData.leastName = ""
		slotData.leastCount = 0
		slotData.leastModifier = 0
		for i = 1, 16 do
			local count = turtle.getItemCount(i)
			if count > 0 then
				data = turtle.getItemDetail(i)
				if data.name == item and (data.damage == useDamage or useDamage == -1) then
					total = total + count
					if count > slotData.mostCount then--
						slotData.mostSlot = i
						slotData.mostName = data.name
						slotData.mostCount = count
						slotData.mostModifier = data.damage
					end
					if count < slotData.leastCount then--
						slotData.leastSlot = i
						slotData.leastName = data.name
						slotData.leastCount = count
						slotData.leastModifier = data.damage
					end
				end
			end
		end
		if slotData.mostSlot > 0 then
			if slotData.leastSlot == 0 then
				slotData.leastSlot = slotData.mostSlot
				slotData.leastName = slotData.mostName
				slotData.leastCount = slotData.mostCount
				slotData.leastModifier = slotData.mostModifier
			end
		end
		
		return slotData.leastSlot, slotData.leastModifier, total, slotData -- first slot no, integer, integer, table
	end
	
	function clsTurtle.getPlaceChestDirection(self)
		local facing = self.facing
		local chestDirection = "forward"
		while turtle.detect() do --check for clear space to place chest
			clsTurtle.turnRight(self, 1)
			if facing == self.facing then -- full circle
				--check up and down
				if turtle.detectDown() then -- no space below
					if turtle.detectUp() then
						if clsTurtle.dig(self, "up") then
							chestDirection = "up"
						end
					else
						chestDirection = "up"
					end
				else
					chestDirection = "down"
				end
				break
			end
		end
		return chestDirection
	end
	
	function clsTurtle.getSlotContains(self, slotNo)
		local data = {} --initialise empty table variable
		
		local slotCount = 0
		local slotContains = ""
		local slotDamage = 0
		if turtle.getItemCount(slotNo) > 0 then
			data = turtle.getItemDetail(slotNo)
			slotCount = data.count
			slotContains = data.name
			slotDamage = data.damage
		end
		
		return slotCount, slotContains, slotDamage
	end
	
	function clsTurtle.getStock(self, item, modifier)
		-- return total units and slot numbers of max and min amounts
		local slot, damage, total, slotData = clsTurtle.getItemSlot(self, item, modifier) --return .leastSlot, .leastModifier, total, slotData
		local rt = {}
		rt.total = total
		rt.mostSlot = slotData.mostSlot
		rt.leastSlot = slotData.leastSlot
		rt.mostCount = slotData.mostCount
		rt.leastCount = slotData.leastCount
		if slot == 0 then
			if modifier == nil then
				--clsTurtle.saveToLog(self, "getStock()"..tostring(item).."= not found", true)
			else
				--clsTurtle.saveToLog(self, "getStock()"..tostring(item).."("..tostring(modifier)..")= not found")
			end
		end
		
		return rt --{rt.total, rt.mostSlot, rt.leastSlot, rt.mostCount, rt.leastCount}
	end
	
	function clsTurtle.getSolidBlockCount(self)
		local retValue = 0
		local slotCount, slotContains, slotDamage
		for i = 1, 16 do
			slotCount, slotContains, slotDamage = clsTurtle.getSlotContains(self, i)
			if slotContains == "minecraft:stone" or slotContains == "minecraft:cobblestone" or slotContains == "minecraft:dirt" then
				retValue = retValue + slotCount
			end
		end
		return retValue
	end
	
	function clsTurtle.getTotalItemCount(self)
		local count = 0
		
		for i = 1, 16 do
			count = count + turtle.getItemCount(i)
		end
		return count
	end
	
	function clsTurtle.go(self, path, useTorch, torchInterval, leaveExisting, checkDungeon)
		useTorch = useTorch or false -- used in m an M to place torches in mines
		if leaveExisting == nil then
			leaveExisting = false
		end
		if checkDungeon == nil then
			checkDungeon = false
		end
		torchInterval = torchInterval or 8
		local intervalList = {1, torchInterval * 1 + 1,
								 torchInterval * 2 + 1,
								 torchInterval * 3 + 1,
								 torchInterval * 4 + 1,
								 torchInterval * 5 + 1,
								 torchInterval * 6 + 1}
		local slot = turtle.getSelectedSlot()
		turtle.select(1)		
		local commandList = {}
		local command = ""
		-- remove spaces from path
		path = string.gsub(path, " ", "")
		-- make a list of commands from path string eg "x0F12U1" = x0, F12, U1
		for i = 1, string.len(path) do
			local character = string.sub(path, i, i) -- examine each character in the string
			if tonumber(character) == nil then -- char is NOT a number
				if command ~= "" then -- command is NOT empty eg "x0"
					table.insert(commandList, command) -- add to table eg "x0"
				end
				command = character -- replace command with new character eg "F"
			else -- char IS a number
				command = command..character -- add eg 1 to F = F1, 2 to F1 = F12
				if i == string.len(path) then -- last character in the string
					table.insert(commandList, command)
				end
			end
		end
		-- R# L# F# B# U# D# +0 -0 d0 = Right, Left, Forward, Back, Up, Down, up while detect and return, down while not detect, down and place while not detect
		-- dig:			  x0,x1,x2 (up/fwd/down)
		-- suck:		  s0,s1,s2
		-- place chest:   H0,H1,H2 
		-- place sapling: S0,S1,S2
		-- place Torch:   T0,T1,T2
		-- place Hopper:  P0,P1,P2
		-- mine floor:	  m# = mine # blocks above and below, checking for valuable items below, and filling space with cobble or dirt
		-- mine ceiling:  M# = mine # blocks, checking for valuable items above, and filling space with cobble or dirt
		-- mine ceiling:  N# same as M but not mining block below unless valuable
		-- place:		  C,H,r,S,T,P,^ = Cobble / cHest / DIrT / Sapling / Torch / hoPper /stair in direction 0/1/2 (up/fwd/down) eg C2 = place cobble down
		-- place:         t = 0/1 = place behind, 2 = cobble first, up torch, forward down
		-- place:		  e = ladder direction
		-- place:		  @ = any block in inventory, direction
		clsTurtle.refuel(self, 15)
		turtle.select(1)
		for cmd in clsTurtle.values(self, commandList) do -- eg F12 or x1
			local move = string.sub(cmd, 1, 1)
			local modifier = tonumber(string.sub(cmd, 2))
			if move == "R" then
				clsTurtle.turnRight(self, modifier)
			elseif move == "L" then
				clsTurtle.turnLeft(self, modifier)
			elseif move == "B" then
				clsTurtle.back(self, modifier)
			elseif move == "F" then
				clsTurtle.forward(self, modifier, checkDungeon)
			elseif move == "U" then
				clsTurtle.up(self, modifier, checkDungeon)
			elseif move == "D" then
				clsTurtle.down(self, modifier, checkDungeon)
			elseif move == "+" then
				local height = 0
				while turtle.detectUp() do
					clsTurtle.up(self, 1, checkDungeon)
					height = height + 1
				end
				clsTurtle.down(self, height, checkDungeon)
			elseif move == "-" then
				while not turtle.inspectDown() do
					clsTurtle.down(self, 1, checkDungeon)
				end
			elseif move == "d" then
				if modifier == 1 then
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward", leaveExisting) then
						if not clsTurtle.place(self, "minecraft:dirt", -1, "forward", leaveExisting) then
							clsTurtle.place(self, "minecraft:stone", -1, "forward", leaveExisting)
						end
					end
				end
				while not turtle.detectDown() do
					clsTurtle.down(self, 1, checkDungeon)
					if modifier == 1 then
						if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward", leaveExisting) then
							if not clsTurtle.place(self, "minecraft:dirt", -1, "forward", leaveExisting) then
								clsTurtle.place(self, "minecraft:stone", -1, "forward", leaveExisting)
							end
						end
					end
				end
				if modifier == 1 then
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward", leaveExisting) then
						if not clsTurtle.place(self, "minecraft:dirt", -1, "forward", leaveExisting) then
							clsTurtle.place(self, "minecraft:stone", -1, "forward", leaveExisting)
						end
					end
				end
			elseif move == "u" then -- move up and place forward/down
				repeat
					if modifier == 1 then
						if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward", leaveExisting) then
							if not clsTurtle.place(self, "minecraft:dirt", -1, "forward", leaveExisting) then
								clsTurtle.place(self, "minecraft:stone", -1, "forward", leaveExisting)
							end
						end
					end
					clsTurtle.up(self, 1, checkDungeon)
					if modifier == 1 then
						if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward", leaveExisting) then
							if not clsTurtle.place(self, "minecraft:dirt", -1, "forward", leaveExisting) then
								clsTurtle.place(self, "minecraft:stone", -1, "forward", leaveExisting)
							end
						end
					end
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, "down", leaveExisting) then
						if not clsTurtle.place(self, "minecraft:dirt", -1, "down", leaveExisting) then
							clsTurtle.place(self, "minecraft:stone", -1, "down", leaveExisting)
						end
					end
				until not turtle.inspectUp()
				if modifier == 1 then
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward", leaveExisting) then
						if not clsTurtle.place(self, "minecraft:dirt", -1, "forward", leaveExisting) then
							clsTurtle.place(self, "minecraft:stone", -1, "forward", leaveExisting)
						end
					end
				end
			elseif move == "x" then
				if modifier == 0 then
					clsTurtle.dig(self, "up")
				elseif modifier == 1 then
					clsTurtle.dig(self, "forward")
				elseif modifier == 2 then
					while turtle.detectDown() do
						turtle.digDown()
					end
				end
			elseif move == "s" then
				if modifier == 0 then
					while turtle.suckUp() do end
				elseif modifier == 1 then
					while turtle.suck() do end
				elseif modifier == 2 then
					while turtle.suckDown() do end
				end
			elseif move == "m" then --mine block below and/or fill void
				for i = 1, modifier + 1 do --eg m8 run loop 9 x
					turtle.select(1)
					local isValuable, blockType = clsTurtle.isValuable(self, "down")
					if isValuable or blockType == "minecraft:gravel" then
						turtle.digDown() -- dig if gravel
					else --check for lava
						if blockType == "minecraft:lava" then
							clsTurtle.place(self, "minecraft:bucket", 0, "down")
						end
					end
					clsTurtle.dig(self, "up") -- create player coridoor
					if not turtle.detectDown() then
						if blockType ~= "minecraft:diamond_ore" then
							if not clsTurtle.place(self, "minecraft:cobblestone", -1, "down") then
								clsTurtle.place(self, "minecraft:dirt", -1, "down")
							end
						end
					end
					if i <= modifier then -- m8 = move forward 8x
						if useTorch then
							if  i == intervalList[1] or
								i == intervalList[2] or
								i == intervalList[3] or
								i == intervalList[4] or
								i == intervalList[5] then
								clsTurtle.up(self, 1, checkDungeon)
								clsTurtle.place(self, "minecraft:torch", -1, "down", false)
								clsTurtle.forward(self, 1, checkDungeon)
								clsTurtle.down(self, 1, checkDungeon)
							else
								clsTurtle.forward(self, 1, checkDungeon)
							end
						else
							clsTurtle.forward(self, 1, checkDungeon)
						end
					end
				end
			elseif move == "n" then --mine block below and/or fill void + check left side
				for i = 1, modifier + 1 do --eg m8 run loop 9 x
					turtle.select(1)
					local isValuable, blockType = clsTurtle.isValuable(self, "down")
					if isValuable or blockType == "minecraft:gravel" then
						turtle.digDown() -- dig if valuable or gravel
					else --check for lava
						if blockType == "minecraft:lava" then
							clsTurtle.place(self, "minecraft:bucket", 0, "down")
						end
					end
					clsTurtle.dig(self, "up") -- create player coridoor
					if not turtle.detectDown() then
						if blockType ~= "minecraft:diamond_ore" then
							if not clsTurtle.place(self, "minecraft:cobblestone", -1, "down") then
								clsTurtle.place(self, "minecraft:dirt", -1, "down")
							end
						end
					end
					clsTurtle.turnLeft(self, 1)
					local isValuable, blockType = clsTurtle.isValuable(self, "forward")
					if isValuable then
						turtle.dig() -- dig if valuable
					end
					if not turtle.detect() then
						if blockType ~= "minecraft:diamond_ore" then
							if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward") then
								clsTurtle.place(self, "minecraft:dirt", -1, "forward")
							end
						end
					end
					clsTurtle.turnRight(self, 1)	
					if i <= modifier then -- m8 = move forward 8x
						if useTorch then
							if  i == intervalList[1] or
								i == intervalList[2] or
								i == intervalList[3] or
								i == intervalList[4] or
								i == intervalList[5] then
								clsTurtle.up(self, 1, checkDungeon)
								clsTurtle.place(self, "minecraft:torch", -1, "down", false)
								clsTurtle.forward(self, 1, checkDungeon)
								clsTurtle.down(self, 1, checkDungeon)
							else
								clsTurtle.forward(self, 1, checkDungeon)
							end
						else
							clsTurtle.forward(self, 1, checkDungeon)
						end
					end
				end
			elseif move == "M" then --mine block above and/or fill void
				for i = 1, modifier + 1 do
					turtle.select(1)
					local isValuable, blockType = clsTurtle.isValuable(self, "up")
					if isValuable then
						clsTurtle.dig(self, "up")
					else --check for lava
						if clsTurtle.getBlockType(self, "up") == "minecraft:lava" then
							clsTurtle.place(self, "minecraft:bucket", 0, "up")
						end
					end
					if not turtle.detectUp()then
						if blockType ~= "minecraft:diamond_ore" then
							if not clsTurtle.place(self, "minecraft:cobblestone", -1, "up") then
								clsTurtle.place(self, "minecraft:dirt", -1, "up")
							end
						end
					end
					if i <= modifier then -- will not move forward if modifier = 0
						if useTorch then
							if  i == intervalList[1] or
								i == intervalList[2] or
								i == intervalList[3] or
								i == intervalList[4] or
								i == intervalList[5] then
								clsTurtle.place(self, "minecraft:torch", 0, "down", false)
							end
						end
						clsTurtle.forward(self, 1, checkDungeon)
					end
				end
			elseif move == "N" then --mine block above and/or fill void + mine block below if valuable
				for i = 1, modifier + 1 do
					turtle.select(1)
					local isValuable, blockType = clsTurtle.isValuable(self, "up")
					if isValuable then
						clsTurtle.dig(self, "up")
					else --check for lava
						if clsTurtle.getBlockType(self, "up") == "minecraft:lava" then
							clsTurtle.place(self, "minecraft:bucket", 0, "up")
						end
					end
					if not turtle.detectUp() then
						if blockType ~= "minecraft:diamond_ore" then
							if not clsTurtle.place(self, "minecraft:cobblestone", -1, "up") then
								clsTurtle.place(self, "minecraft:dirt", -1, "up")
							end
						end
					end
					turtle.select(1)
					if clsTurtle.isValuable(self, "down") then
						turtle.digDown()
					end
					if i <= modifier then
						clsTurtle.forward(self, 1, checkDungeon)
					end
				end
			elseif move == "Q" then --mine block above and/or fill void + mine block below if valuable + left side
				for i = 1, modifier + 1 do
					turtle.select(1)
					if clsTurtle.isValuable(self, "up") then
						clsTurtle.dig(self, "up")
					else --check for lava
						if clsTurtle.getBlockType(self, "up") == "minecraft:lava" then
							clsTurtle.place(self, "minecraft:bucket", 0, "up")
						end
					end
					if not turtle.detectUp() then
						if not clsTurtle.place(self, "minecraft:cobblestone", -1, "up") then
							clsTurtle.place(self, "minecraft:dirt", -1, "up")
						end
					end
					clsTurtle.turnLeft(self, 1)
					if clsTurtle.isValuable(self, "forward") then
						turtle.dig() -- dig if valuable
					end
					if not turtle.detect() then
						if not clsTurtle.place(self, "minecraft:cobblestone", -1, "forward") then
							clsTurtle.place(self, "minecraft:dirt", -1, "forward")
						end
					end
					clsTurtle.turnRight(self, 1)	
					if clsTurtle.isValuable(self, "down") then
						turtle.digDown()
					end
					if i <= modifier then
						clsTurtle.forward(self, 1, checkDungeon)
					end
				end
			elseif move == "C" or move == "H" or move == "r" or move == "T" or move == "S" or move == "P" or move == "@" then --place item up/forward/down
				-- clsTurtle.place(self, blockType, damageNo, direction, leaveExisting)
				
				local placeItem = "minecraft:cobblestone"
				local direction = {"up", "forward", "down"}
				if move == "H" then
					placeItem = "minecraft:chest"
				elseif move == "r" then
					placeItem = "minecraft:dirt"
				elseif move == "T" then
					placeItem = "minecraft:torch"
				elseif move == "S" then
					placeItem = "minecraft:sapling"
				elseif move == "P" then
					placeItem = "minecraft:hopper"
				elseif move == "@" then -- any item in inventory
					placeItem = ""
				end
				--[[
				if modifier == 0 then
					clsTurtle.dig(self, "up")
				elseif modifier == 1 then
					clsTurtle.dig(self, "forward")
				else
					turtle.digDown()
				end]]
				if move == "C" then
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, direction[modifier + 1], leaveExisting) then
						if not clsTurtle.place(self, "minecraft:dirt", -1, direction[modifier + 1], leaveExisting) then
							clsTurtle.place(self, "minecraft:stone", -1, direction[modifier + 1], leaveExisting)
						end
					end
				else
					clsTurtle.place(self, placeItem, -1, direction[modifier + 1], leaveExisting)
				end
			elseif move == "t" then
				-- 0 = placeUp does not work with os 1.8
				-- 1 = turn round, placeForward
				-- 2 = placeDown
				-- 3 = turnLeft, placeUp
				-- 4 = turnround, placeUp
				-- 5 = place down without block
				if modifier == 0 then -- os < 1.8
					clsTurtle.place(self, "minecraft:torch", -1, "up", false)
				elseif modifier == 1 then --place behind
					clsTurtle.turnLeft(self, 2)
					--local block, blockType = clsTurtle.isWaterOrLava(self, "forward")
					--if block ~= "minecraft:water" and block ~= "minecraft:lava" then
						clsTurtle.place(self, "minecraft:torch", -1, "forward", false)
					--end
					clsTurtle.turnLeft(self, 2)
				elseif modifier == 2 then -- place below for 2
					if not clsTurtle.place(self, "minecraft:cobblestone", -1,"down") then
						clsTurtle.place(self, "minecraft:dirt", -1, "down", leaveExisting)
					end
					clsTurtle.up(self, 1, checkDungeon)
					--local block, blockType = clsTurtle.isWaterOrLava(self, "down")
					--if block ~= "minecraft:water" and block ~= "minecraft:lava" then
						clsTurtle.place(self, "minecraft:torch", -1, "down", false)
					--end
					clsTurtle.forward(self, 1, checkDungeon)
					clsTurtle.down(self, 1, checkDungeon)
				elseif modifier == 3 then --turnLeft, placeUp (on ground to wall)
					clsTurtle.turnLeft(self, 1)
					clsTurtle.place(self, "minecraft:torch", -1, "up", false)
					clsTurtle.turnRight(self, 1)
				elseif modifier == 4 then --turnLeft, placeUp (on ground to wall)
					clsTurtle.turnLeft(self, 2)
					clsTurtle.place(self, "minecraft:torch", -1, "up", false)
					clsTurtle.turnLeft(self, 2)
				elseif modifier == 5 then --cobble first, then torch
					clsTurtle.place(self, "minecraft:torch", -1, "down", false)
				end
			elseif move == "e" then -- ladder above / in front / below
				local direction = {"up", "forward", "down"}
				clsTurtle.place(self, "minecraft:ladder", -1, direction[modifier + 1], false)
			elseif move == "*" then
				local goUp = 0
				while not turtle.inspectDown() do
					clsTurtle.down(self, 1, checkDungeon)
					goUp = goUp + 1
				end
				if goUp > 0 then
					for i = 1, goUp do
						clsTurtle.up(self, 1, checkDungeon)
						if not clsTurtle.place(self, "minecraft:cobblestone", -1, "down") then
							clsTurtle.place(self, "minecraft:dirt", -1, "down")
						end
					end
					goUp = 0
				else
					turtle.digDown()
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, "down") then
						clsTurtle.place(self, "minecraft:dirt", -1, "down")
					end
				end
			elseif move == "c" then
				if turtle.detectDown() then
					--check if vegetation and remove
					data = clsTurtle.getBlockType(self, "down")
					if data.name ~= "minecraft:dirt" and data.name ~= "minecraft:stone" and data.name ~= "minecraft:cobblestone" and data.name ~= "minecraft:grass" then
						turtle.digDown()
					end
				end
				if not turtle.detectDown() then
					if not clsTurtle.place(self, "minecraft:cobblestone", -1, "down") then
						clsTurtle.place(self, "minecraft:dirt", -1, "down")
					end
				end
			elseif move == "Z" then -- mine to bedrock
				for i = 1, modifier + 1 do	
					turtle.select(1)
					local goUp = 0
					while clsTurtle.down(self, 1, checkDungeon) do
						goUp = goUp + 1
					end
					for j = goUp, 1, -1 do
						for k = 1, 4 do
							clsTurtle.turnRight(self, 1)
							if clsTurtle.isValuable(self, "forward") then
								clsTurtle.place(self, "minecraft:cobblestone", -1, "forward")
							end
						end
						clsTurtle.up(self, 1, checkDungeon)
						clsTurtle.place(self, "minecraft:cobblestone", -1, "down")
						turtle.select(1)
					end
					if i <= modifier then 
						clsTurtle.forward(self, 2, checkDungeon)
					end
				end
			elseif move == "^" then --place stair
				local direction = {"up", "forward", "down"}
				if not clsTurtle.place(self, "minecraft:stone_stairs", -1, direction[modifier + 1], false) then -- ending false forces block replacement
					print("could not place stairs")
					clsTurtle.place(self, "minecraft:cobblestone", -1, direction[modifier + 1], false)
				end
			end
		end
		turtle.select(slot)
	end
	
	function clsTurtle.harvestTree(self, extend, craftChest, direction)
		extend = extend or false
		craftChest = craftChest or false
		direction = direction or "forward"
		local goHeight = 0
		local addHeight = 0
		local onLeft = true
		if direction == "forward" then
			turtle.dig()       -- dig base of tree
			clsTurtle.forward(self, 1) -- go under tree with 1 log. Will refuel if needed
		end
		-- check if on r or l of double width tree
		clsTurtle.turnLeft(self, 1)
		if clsTurtle.getBlockType(self, "forward") == "minecraft:log" or clsTurtle.getBlockType(self, "forward") == "minecraft:log2" then
			onLeft = false -- placed on right side of 2 block tree
		end
		clsTurtle.turnRight(self, 1)
		if craftChest then
			clsTurtle.dig(self, "up")
			clsTurtle.up(self, 1)
			clsTurtle.dig(self, "up")
			while clsTurtle.down(self, 1) do end
			clsTurtle.craft(self, "minecraft:planks", 8)
			clsTurtle.craft(self, "minecraft:chest", 1)
			while clsTurtle.up(self, 1) do
				goHeight = goHeight + 1
			end
		end
		-- Loop to climb up tree and harvest trunk and surrounding leaves
		while clsTurtle.dig(self, "up") do -- continue loop while block detected above
			if clsTurtle.up(self, 1) then   -- Move up
				goHeight = goHeight + 1
			end
			-- Inner loop to check for leaves
			for i = 1, 4 do
				if turtle.detect() then -- check if leaves in front
					clsTurtle.dig(self, "forward") --Dig leaves
				end
				clsTurtle.turnRight(self, 1)
			end
		end
		-- At top of the tree. New loop to return to ground
		if extend then
			if onLeft then
				clsTurtle.go(self, "F1R1F1R2")
			else
				clsTurtle.go(self, "F1L1F1R2")
			end
			while turtle.detectUp() do
				clsTurtle.up(self, 1)
				addHeight = addHeight + 1
			end
			if addHeight > 0 then
				clsTurtle.down(self, addHeight)
			end
		end
		for i = 1, goHeight do
			clsTurtle.down(self, 1)
		end
		if extend then
			if onLeft then
				clsTurtle.go(self, "F1L1F1R2")
			else
				clsTurtle.go(self, "F1R1F1R2")
			end
		end
	end
	
	function clsTurtle.harvestWholeTree(self, direction)	
		--RECURSIVE FUNCTION - BEWARE!
		local blockType, modifier
		if direction == "up" then
			clsTurtle.refuel(self, 15)
			if clsTurtle.isLog(self, "up") then
				clsTurtle.up(self, 1)
				if clsTurtle.isLog(self, "up") then
					clsTurtle.harvestWholeTree(self, "up")
				end
			end
			for i = 1, 4 do
				-- check all round
				if clsTurtle.isLog(self, "forward") then
					clsTurtle.harvestWholeTree(self, "forward")
				else
					blockType, modifier = clsTurtle.getBlockType(self, "forward")
					if blockType == "minecraft:leaves" then
						clsTurtle.forward(self, 1)
						clsTurtle.harvestWholeTree(self, "forward")
						clsTurtle.back(self, 1)
					end
				end
				clsTurtle.turnRight(self, 1)
			end
			clsTurtle.down(self, 1)
			for i = 1, 4 do
				-- check all round
				if clsTurtle.isLog(self, "forward") then
					clsTurtle.harvestWholeTree(self, "forward")
				else
					blockType, modifier = clsTurtle.getBlockType(self, "forward")
					if blockType == "minecraft:leaves" then
						clsTurtle.forward(self, 1)
						clsTurtle.harvestWholeTree(self, "forward")
						clsTurtle.back(self, 1)
					end
				end
				clsTurtle.turnRight(self, 1)
			end
		elseif direction == "forward" then
			if clsTurtle.isLog(self, "forward") then
				clsTurtle.refuel(self, 15)
				
				clsTurtle.forward(self, 1)
				if turtle.detectUp() then
					turtle.digUp()
				end
				if clsTurtle.isLog(self, "forward") then
					clsTurtle.harvestWholeTree(self, "forward")
				end
				--check left side
				clsTurtle.turnLeft(self, 1)
				if clsTurtle.isLog(self, "forward") then
					clsTurtle.harvestWholeTree(self, "forward")
				end
				-- check right side
				clsTurtle.turnRight(self, 2)
				if clsTurtle.isLog(self, "forward") then
					clsTurtle.harvestWholeTree(self, "forward")
				end
				clsTurtle.turnLeft(self, 1)
				clsTurtle.back(self, 1)
			end
		end
	end
	
	function clsTurtle.isDungeon(self, direction) 
		local success = false
		local blockType, blockModifier = clsTurtle.getBlockType(self, direction)
		if blockType == "minecraft:mossy_cobblestone" or blockType == "minecraft:cobblestone" then --block found
			success = true
		end
		return success
	end
	
	function clsTurtle.isLog(self, direction) 
		local success = false
		local blockType, modifier
		
		local valuableItems = "minecraft:log minecraft:log2"

		if direction == "up" then
			if turtle.detectUp() then
				blockType, modifier = clsTurtle.getBlockType(self, "up")
			end
		elseif direction == "down" then
			if turtle.detectDown() then
				blockType, modifier = clsTurtle.getBlockType(self, "down")
			end
		elseif direction == "forward" then
			if turtle.detect() then
				blockType, modifier = clsTurtle.getBlockType(self, "forward")
			end
		end
		if blockType ~= nil then
			if string.find(valuableItems, blockType) ~= nil then
				success = true
			end
		end
		
		return success
	end
	
	function clsTurtle.isValuable(self, direction) 
		local success = false
		local blockType = ""
		local blockModifier

		local itemList = "minecraft:dirt,minecraft:grass,minecraft:stone,minecraft:gravel,minecraft:chest,"..
						 "minecraft:cobblestone,minecraft:sand,minecraft:torch,minecraft:bedrock,minecraft:ladder"
		
		if direction == "up" then
			if turtle.detectUp() then
				blockType, blockModifier = clsTurtle.getBlockType(self, "up")
			end
		elseif direction == "down" then
			if turtle.detectDown() then
				blockType, blockModifier = clsTurtle.getBlockType(self, "down")
			end
		elseif direction == "forward" then
			if turtle.detect() then
				blockType, blockModifier = clsTurtle.getBlockType(self, "forward")
			end
		end
		if blockType ~= "" then --block found
			success = true
			if string.find(itemList, blockType) ~= nil then
				success = false
			end
		end
		if success then
			-- check if diamond. if so ensure space in inventory
			if blockType == "minecraft:diamond_ore" then
				clsTurtle.dumpRefuse(self)
			end
		end
		return success, blockType
	end
	
	function clsTurtle.isVegetation(self, blockName)
		blockName = blockName or ""
		local isVeg = false
		local vegList = {"minecraft:tallgrass", "minecraft:deadbush", "minecraft:cactus", "minecraft:leaves",
						 "minecraft:pumpkin", "minecraft:melon_block", "minecraft:vine", "minecraft:mycelium", "minecraft:waterliliy",
						 "minecraft:cocoa", "minecraft:double_plant", "minecraft:sponge", "minecraft:wheat"}
		
		-- check for flower, mushroom
		if string.find(blockName, "flower") ~= nil or string.find(blockName, "mushroom") ~= nil then
			isVeg = true
		end
		if not isVeg then
			for _,v in pairs(vegList) do
				if v == blockName then
					isVeg = true
					break
				end
			end
		end
		
		return isVeg
	end
	
	function clsTurtle.isWaterOrLava(self, direction)
		direction = direction or "forward"
		local block = ""
		local blockType = -1
		if not clsTurtle.detect(self, direction) then --air, water or lava
			--print("block "..direction.." is air, water or lava")
			block, blockType = clsTurtle.getBlockType(self, direction)
			--print("block "..direction.." is "..tostring(block).." metadata = "..tostring(blockType))
			if block == nil then
				block = ""
				blockType = -1
			elseif block == "minecraft:lava" then
				clsTurtle.place(self, "minecraft:bucket", -1, direction, false)
			end
		end
		return block, blockType
	end
	
	function clsTurtle.menu(self, title, list)
		local retValue = 0
		response = true
		while response do
			response = false
			clsTurtle.clear(self)
			print(title.."\n")
			for i = 1, #list, 1 do
				print("\t"..i..".  "..list[i])
			end
			print("Type number of your choice (1 to "..#list..")_")
			event, param1 = os.pullEvent ("char")
			local choice = tonumber(param1)
			if choice ~= nil then -- number typed
				if choice >= 1 or choice <= #list then
					retValue = choice
				end
			else
				print()
				print("Incorrect input: "..param1)
				print()
				print("Type numbers only, from 1 to "..#list)
				sleep(2)
				response = true
			end
		end
		return retValue -- 1 to no of items in the list
	end
	
	function clsTurtle.place(self, blockType, damageNo, direction, leaveExisting)
		if leaveExisting == nil then
			leaveExisting = true
		end
		local success = false
		local doContinue = true
		local slot
		local dig = true
		if blockType == "" then --use any
			slot = turtle.getSelectedSlot()
			if  clsTurtle.getItemName(self, i) == "minecraft:sand" or clsTurtle.getItemName(self, i) == "minecraft:gravel" then
				for i = 1, 16 do
					if turtle.getItemCount(i) > 0 then
						local name = clsTurtle.getItemName(self, i)
						if  name ~= "minecraft:sand" and name ~= "minecraft:gravel" then
							slot = i
							print("debug ".. name.." found slot "..i)
							break
						end
					end
				end
			end
		else
			slot = clsTurtle.getItemSlot(self, blockType, damageNo)
		end
		local existingBlock, modifier = clsTurtle.getBlockType(self, direction)
		if leaveExisting then -- do not remove existing block unless sand gravel water or lava
			-- check if water / lava
			if clsTurtle.detect(self, direction) then -- not water or lava
				if blockType == "" then -- place any block
					if existingBlock ~= "minecraft:sand" and existingBlock ~= "minecraft:gravel" then --leave anything except sand/gravel		
						print("debug existing block: "..existingBlock)
						doContinue = false
						success = true
					end
				else --place specific block
					-- ignore dirt, grass, stone, cobble
					if existingBlock == "minecraft:dirt" or existingBlock == "minecraft:stone" or
					   existingBlock == "minecraft:cobblestone" or existingBlock == "minecraft:grass" then			
						doContinue = false
						success = true
					end
				end
			end		
		end
		if doContinue then -- water or lava in next block or leaveExisting = false
			while clsTurtle.dig(self, direction) do
				sleep(0.5)
			end
			if slot > 0 then
				if direction == "down" then
					turtle.select(slot)
					if turtle.placeDown() then
						if blockType == "minecraft:bucket" then
							if turtle.refuel() then
								--clsTurtle.saveToLog("Refuelled with lava. Current fuel level: "..turtle.getFuelLevel())
							end
						end
						success = true
					else -- not placeDown
						if blockType == "" then
							local done = false
							while not done do
								for i = 1, 16 do
									if turtle.getItemCount(i) > 0 then
										if  clsTurtle.getItemName(self, i) ~= "minecraft:sand" and clsTurtle.getItemName(self, i) ~= "minecraft:gravel" then
											turtle.select(i)
											if turtle.placeDown() then
												done = true
												success = true
												break
											end
										end
									end
								end
								if not done then
									print("Out of blocks to place")
									sleep(10)
								end
							end
						else
							if not clsTurtle.attack(self, "down") then
								print("Error placing "..blockType.." ? chest or minecart below")
								--clsTurtle.saveToLog("Error placing "..blockType.." ? chest or minecart below")
							end
						end
					end
				elseif direction == "up" then
					turtle.select(slot)
					if turtle.placeUp() then
						if blockType == "minecraft:bucket" then
							if turtle.refuel() then
								--clsTurtle.saveToLog("Refuelled with lava. Current fuel level: "..turtle.getFuelLevel())
							end
						end
						success = true
					else
						if blockType == "" then
							local done = false
							while not done do
								for i = 1, 16 do
									if turtle.getItemCount(i) > 0 then
										if  clsTurtle.getItemName(self, i) ~= "minecraft:sand" and clsTurtle.getItemName(self, i) ~= "minecraft:gravel" then
											turtle.select(i)
											if turtle.placeUp() then
												success = true
												done = true
												break
											end
										end
									end
								end
								if not done then
									print("Out of blocks to place")
									sleep(10)
								end
							end
						end
					end
				else -- place forward
					turtle.select(slot)
					if turtle.place() then
						if blockType == "minecraft:bucket" then
							if turtle.refuel() then
								print("Refuelled with lava. Current fuel level: "..turtle.getFuelLevel())
								--clsTurtle.saveToLog("Refuelled with lava. Current fuel level: "..turtle.getFuelLevel())
							end
						end
						success = true
					else --block not placed
						if blockType == "" then --any block will do
							local done = false
							while not done do
								for i = 1, 16 do
									if turtle.getItemCount(i) > 0 then
										if  clsTurtle.getItemName(self, i) ~= "minecraft:sand" and clsTurtle.getItemName(self, i) ~= "minecraft:gravel" then
											turtle.select(i)
											if turtle.place() then
												success = true
												done = true
												break
											end
										end
									end
								end
								if not done then
									print("Out of blocks to place. Remove sand and gravel")
									sleep(10)
								end
							end
						end
					end
				end
			end
		end
		return success, slot
	end
	
	function clsTurtle.refuel(self, minLevel)	
		minLevel = minLevel or 15
		local itemSlot = 0
		local slot = turtle.getSelectedSlot()
		local count = 0
		local item = ""
		local damage = 0
		local refuelOK = false

		if turtle.getFuelLevel() < minLevel or minLevel == 0 then
			-- check each slot for fuel item
			for i = 1, 16 do
				count, item, damage = clsTurtle.getSlotContains(self, i)
				if item == "minecraft:lava_bucket" then
					turtle.select(i)
					if turtle.refuel(1) then
						print("refuelled with lava: "..turtle.getFuelLevel())
						refuelOK = true
						break
					end
				end
				if item == "minecraft:coal" then
					turtle.select(i)
					if turtle.refuel(1) then
						while turtle.getFuelLevel() < minLevel and turtle.getItemCount(i) > 0 do
							turtle.refuel(1)
						end
						print("refuelled with coal: "..turtle.getFuelLevel())
						refuelOK = true
					end
				end
			end
			if not refuelOK then
				for i = 1, 16 do
					count, item, damage = clsTurtle.getSlotContains(self, i)
					if item == "minecraft:planks" then
						turtle.select(i)
						if turtle.refuel(1) then
							while turtle.getFuelLevel() < minLevel and turtle.getItemCount(i) > 0 do
								turtle.refuel(1)
							end
							print("refuelled with planks: "..turtle.getFuelLevel())
							refuelOK = true
						end
					end
				end
			end
			if not refuelOK then
				local success = false
				for i = 1, 16 do
					count, item, damage = clsTurtle.getSlotContains(self, i)
					if item == "minecraft:log" or item == "minecraft:log2"  then --logs onboard
						print("Refuelling with log slot "..tostring(i)..", crafting planks")
						if clsTurtle.craft(self, "minecraft:planks", 4) then
							success = true
						else
							print("refuel() error crafting planks")
						end
						if success then
							local planksSlot, damage, count = T:getItemSlot("minecraft:planks")
							turtle.select(planksSlot)
							if turtle.refuel() then
								refuelOK = true
							end
						end
					end
				end
			end
			if not refuelOK and turtle.getFuelLevel() == 0 then
				--term.clear()
				term.setCursorPos(1,1)
				print("Unable to refuel: "..turtle.getFuelLevel().." fuel remaining")
				error()
			end
		end
		turtle.select(slot)
		
		return refuelOK
	end
	
	function clsTurtle.selectPlaceItem(self, item, useDamage)
		local success = false
		clsTurtle.getItemSlot(self, item, useDamage)
		if self.placeSlot > 0 then
			self.placeItem = item
		end
	end
	
	function clsTurtle.setEquipment(self)
		-- if contains a crafting table, puts it on the right. Any other tool on the left
		clsTurtle.clear(self)
		print("Setting up equipment...")
		local emptySlotR = clsTurtle.getFirstEmptySlot(self) -- first empty slot
		if emptySlotR == 0 then -- all slots full
			turtle.select(16)
			turtle.drop()
			emptySlotR = 16
		end
		local emptySlotL = 0 -- used later
		local eqRight = "" 
		local eqLeft = ""
		local equippedRight = "" 
		local equippedLeft = ""
		local count = 0
		local damage = 0
		local pickaxeSlot, damage, total = clsTurtle.getItemSlot(self, "minecraft:diamond_pickaxe")
		local craftTableSlot, damage, total = clsTurtle.getItemSlot(self, "minecraft:crafting_table")
		if emptySlotR > 0 then -- empty slot found
			turtle.select(emptySlotR)
			if turtle.equipRight() then -- remove tool on the right
				count, eqRight, damage = clsTurtle.getSlotContains(self, emptySlotR) -- eqRight contains name of tool from right side
				if eqRight == "minecraft:crafting_table" then
					craftTableSlot = emptySlotR
					eqRight = "" 
				elseif eqRight == "minecraft:diamond_pickaxe" then
					pickaxeSlot = emptySlotR
					eqRight = "" 
				end -- eqRight 
				emptySlotL = clsTurtle.getFirstEmptySlot(self) -- get next empty slot
				if emptySlotL == 0 then -- all slots full
					if emptySlotR ~= 15 then
						turtle.select(15)
						turtle.drop()
						emptySlotL = 15
					else
						turtle.select(16)
						turtle.drop()
						emptySlotL = 16
					end
				end
			else -- nothing equipped on right side
				emptySlotL = emptySlotR
			end
			if emptySlotL > 0 then -- empty slot found
				turtle.select(emptySlotL)
				if turtle.equipLeft() then -- remove tool on the left
					count, eqLeft, damage = clsTurtle.getSlotContains(self, emptySlotL) -- eqLeft contains name of tool from left side
					if eqLeft == "minecraft:diamond_pickaxe" then
						pickaxeSlot = emptySlotL
						eqLeft = "" 
					elseif eqLeft == "minecraft:crafting_table" then
						craftTableSlot = emptySlotL
						eqLeft = ""
					end
				end
			end
			if pickaxeSlot > 0 then
				turtle.select(pickaxeSlot)
				turtle.equipLeft()
				equippedLeft = "minecraft:diamond_pickaxe"		
			end
			if craftTableSlot > 0 then
				turtle.select(craftTableSlot)
				turtle.equipRight()
				equippedRight = "minecraft:crafting_table"		
			end
		end
		-- any tools equipped except diamond_pickaxe and crafting_table have been removed to inventory
		return equippedRight, equippedLeft
	end
		
	function clsTurtle.sortInventory(self)
		local turns = 0
		local chestSlot = clsTurtle.getItemSlot(self, "minecraft:chest", -1) --get the slot number containing a chest
		local blockType, blockModifier
		local facing = self.facing
		--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) started chest found in slot "..chestSlot, true)
		if chestSlot > 0 then -- chest found
			-- find empty block to place it.
			local chestDirection = clsTurtle.getPlaceChestDirection(self)
			blockType, blockModifier = clsTurtle.getBlockType(self, chestDirection)
			--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) looking "..chestDirection.." for chest...", true)
			while blockType ~= "minecraft:chest" do --check if chest placed eg mob in the way
				if clsTurtle.place(self, "minecraft:chest", -1, chestDirection) then
					--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) chest placed:"..chestDirection, true)
					break
				else
					--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) chest NOT placed:"..chestDirection, true)
					clsTurtle.dig(self, chestDirection) -- will force wait for mob
					chestDirection = clsTurtle.getPlaceChestDirection(self)
				end
				blockType, blockModifier = clsTurtle.getBlockType(self, chestDirection)
			end
			-- fill chest with everything
			--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) emptying turtle:"..chestDirection, true)
			for i = 1, 16 do
				clsTurtle.drop(self, i, chestDirection)
			end
			-- remove everything
			--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) refilling turtle:"..chestDirection, true)
			while clsTurtle.suck(self, chestDirection) do end
			clsTurtle.dig(self, chestDirection) -- collect chest
			--clsTurtle.saveToLog(self, "clsTurtle.sortInventory(self) chest collected("..chestDirection..")", true)
			while facing ~= self.facing do --return to original position
				clsTurtle.turnLeft(self, 1)
			end
		end
	end
	
	function clsTurtle.suck(self, direction)
		direction = direction or "forward"
		turtle.select(1)
		local success = false
		if direction == "up" then
			if turtle.suckUp() then
				success = true
			end
		elseif direction == "down" then
			if turtle.suckDown() then
				success = true
			end
		else
			if turtle.suck() then
				success = true
			end
		end
		return success
	end
		
	function clsTurtle.writeCoords(self, filename)
		-- create/overwrite e.g 'DungeonCoords.txt'
		local fileHandle = fs.open(filename, "w")
		fileHandle.writeLine("x="..self.x)
		fileHandle.writeLine("y="..self.y)
		fileHandle.writeLine("z="..self.z)
		fileHandle.writeLine("f="..self.facing)
		fileHandle.close()
		clsTurtle.saveToLog(self, filename.." file created", true)
		clsTurtle.saveToLog(self, "x = "..T:getX()..", y = "..T:getY()..", z = "..T:getZ()..", f = "..T:getFacing(), false)
	end
	
	--self.equippedRight, self.equippedLeft = clsTurtle.setEquipment(self) -- set in equipped items
    
	return self
end
--**********Functions**********
function checkFuelNeeded(quantity)
	local fuelNeeded = quantity - turtle.getFuelLevel() -- eg 600
	if fuelNeeded > 0 then
		T:checkInventoryForItem({"minecraft:lava_bucket", "minecraft:coal", "minecraft:planks"}, {1, math.ceil(fuelNeeded / 60), math.ceil(fuelNeeded / 15)}) -- 0 if not present
	end
end

function checkInventory(choice, size, width, length, height)
	-- run this loop 2x per second to check if player has put anything in the inventory
	-- fuel 1 coal = 60 = 4 planks. 64 planks = 16 coal = 960 units
	local retValue = ""
	local gotBirchSaplings = 0
	local gotCoal = 0
	local gotCobble = 0
	local gotDirt = 0
	local gotOakSaplings = 0
	local gotPlanks = 0
	local gotTorches = 0
	local thanks = "Thank you.\n\nPress the ESC key\n\nStand Back..\n"
	
	if choice >= 12 and choice  <= 16 then
		T:getCoords(true)
		home = createCoordinatesObject("homeLocation")
		home:setAllValues(T:getX(), T:getY(), T:getZ(), T:getFacing())
	end
	T:clear()
	if choice == 0 then --Missing pickaxe
		T:checkInventoryForItem({"minecraft:diamond_pickaxe"}, {1})
		print("Diamond Pickaxe being tested...")
		T:setEquipment()
	elseif choice == 1 then --Missing crafting table
		T:checkInventoryForItem({"minecraft:crafting_table", ""}, {1, 0}) -- 0 if not present
		print("Crafting table being tested...")
		T:setEquipment()
	elseif choice == 2 then --Missing chest
		retValue = T:checkInventoryForItem({"minecraft:chest"}, {1}) -- 0 if not present
		--print("Thanks for the "..retValue.."\n Continuing...")
		sleep(1.5)
	elseif choice == 11 then --Create Mine
		checkFuelNeeded(960)
		T:checkInventoryForItem({"minecraft:torch"}, {24}, false)
		T:checkInventoryForItem({"minecraft:cobblestone"}, {32})
		T:checkInventoryForItem({"minecraft:chest"}, {1})
		--print(thanks)
		sleep(2)
		print("CreateMine starting")
		createMine()
	elseif choice == 12 then	-- ladder to bedrock
		local level = T:getY()
		print("Current saved y level = "..level)
		print("\nIs this correct? (y/n + Enter)")
		if read() ~= "y" then
			level = getSize(true, "Current level (F3->Y coord)?_", 4, 300)
		end
		checkFuelNeeded(level * 2)
		T:checkInventoryForItem({"minecraft:ladder"}, {level})
		T:checkInventoryForItem({"minecraft:cobblestone", "minecraft:dirt"}, {64, 64})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Creating ladder to bedrock")
		createLadder("bedrock", level)
	elseif choice == 13 then	-- ladder to surface
		local level = T:getY()
		print("Current saved y level = "..level)
		print("\nIs this correct? (y/n + Enter)")
		if read() ~= "y" then
			level = getSize(true,"Current level (F3->Y coord)?_", 4, 300)
		end
		checkFuelNeeded((64 - level) * 2)
		T:checkInventoryForItem({"minecraft:ladder"}, {64 - level + 10}) -- allow 10 extra for luck
		T:checkInventoryForItem({"minecraft:cobblestone", "minecraft:dirt"}, {192, 192})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Creating ladder to surface")
		createLadder("surface", level)
	elseif choice == 14 or choice == 15 then	-- stairs to bedrock or surface
		local level = T:getY()
		print("Current saved y level = "..level)
		print("\nIs this correct? (y/n + Enter)")
		if read() ~= "y" then
			level = getSize(true,"Current level (F3->Y coord)?_", 4, 300)
		end
		if level >= 60 then --assume going down
			checkFuelNeeded(level * 10)
		else -- assume going up
			checkFuelNeeded((64 - level) * 10)
		end
		T:clear()
		print("Add any stairs already crafted")
		print("Press enter when ready")
		read()
		local numStairsNeeded = 0
		if choice == 14 then
			numStairsNeeded = math.ceil(level / 4)
		else
			numStairsNeeded = math.ceil((64 - level) / 4)
		end
		local numStairs = T:getItemCount("minecraft:stone_stairs", 0)
		local cobbleNeeded = 256
		if numStairs > 0 then
			cobbleNeeded = 192 - (math.floor((2 * numStairs) / 3))
			if cobbleNeeded < 64 then
				cobbleNeeded = 64
			end
		end
		T:checkInventoryForItem({"minecraft:cobblestone"}, {cobbleNeeded})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		if choice == 14 then
			print("Creating stairs to bedrock")
			createStaircase("bedrock", level)
		else
			print("Creating stairs to surface")
			createStaircase("surface", level)
		end
	elseif choice == 16 then	-- search for mob spawner
		local level = T:getY()
		print("Current saved y level = "..level)
		print("\nIs this correct? (y/n + Enter)")
		if read() ~= "y" then
			level = getSize(true,"Current level (F3->Y coord)?_", 4, 300)
		end
		checkFuelNeeded(3000)
		--T:checkInventoryForItem({"minecraft:ladder"}, {level})
		T:checkInventoryForItem({"minecraft:ladder"}, {6}) 	-- single level per turtle max 6 needed
		T:checkInventoryForItem({"minecraft:bucket"}, {1}) 	-- in case lava found			
		T:checkInventoryForItem({"minecraft:cobblestone", "minecraft:dirt"}, {192, 192})
		T:checkInventoryForItem({"minecraft:torch"}, {160}, false)
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Searching for mob spawner")
		searchForSpawner(level)
	elseif choice == 17 then --Decapitate volcano
		checkFuelNeeded(width * length * 8)
		T:checkInventoryForItem({"minecraft:bucket"}, {1}) 	-- in case lava found
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc		
		print("Decapitatin volcano: size "..width.. " x "..length)
		clearArea(width, length, false)
	elseif choice == 21 or choice == 31 then --Clear area
		checkFuelNeeded(width * length * 3)
		T:checkInventoryForItem({"minecraft:dirt"}, {64})
		print(thanks)
		sleep(2)
		print("Clearing area: size "..width.. " x "..length)
		clearArea(width, length, true)
	elseif choice == 22 then --Create treefarm
		if size == 1 then
			checkFuelNeeded(300)
		else
			checkFuelNeeded(900)
		end
		T:checkInventoryForItem({"minecraft:dirt"}, {64})
		if size == 1 then
			T:checkInventoryForItem({"minecraft:torch"}, {16}, false)
		else
			T:checkInventoryForItem({"minecraft:torch"}, {64}, false)
		end
		print(thanks)
		sleep(2)
		print("CreateTreefarm starting: size "..size)
		createTreefarm(size)
	elseif choice == 23 then -- Plant treefarm
		if size == 1 then
			checkFuelNeeded(180)
		else
			checkFuelNeeded(480)
		end
		T:checkInventoryForItem({"minecraft:sapling"}, {4})
		print(thanks)
		print("plantTreefarm starting: size "..size)
		plantTreefarm(size)
	elseif choice == 24 then	-- Harvest treefarm
		print(thanks)
		os.sleep(2)
		print("Harvesting treefarm starting: size "..size)
		harvestTreeFarm(size)
	elseif choice == 25 then	-- Fell tree
		if T:isLog("forward") then
			T:checkInventoryForItem({"minecraft:chest"}, {1}, false)
			T:forward(1)
			T:harvestWholeTree("up")
			print("Press esc within 2 seconds!")
			os.sleep(2)    -- pause for 2 secs to allow time to press esc
			print("Felling tree")
		else
			print("No log in front..")
			print("Move me in front of a tree!")
			os.sleep(2)    -- pause for 2 secs to allow time to press esc
			retValue = ""
		end
	elseif choice == 26 then	-- Manage auto-treefarm
		-- if turtle in front of:
		-- empty block: assume not constructed, but check air below / chest behind
		-- sapling: wait for growth to tree
		-- tree: assume harvest
		local inFront, subType = T:getBlockType("forward")
		local createNew = false
		sleep(1.5)
		if inFront == nil then -- check if air below
			print("No sapling or tree found\nChecking block below")
			inFront, subType = T:getBlockType("down")
			if inFront == nil then -- air below
				print("No block found below, but no sapling")
				print("or tree in front.\n")
				print("please repair the farm and try again")
				retValue = ""
			else
				createNew = true
			end
		elseif inFront == "minecraft:log" or inFront == "minecraft:log2" then
			harvestAutoTreeFarm()
			plantAutoTreeFarm()
		elseif inFront == "minecraft:sapling" then
			-- wait for trees, or player removes it
			-- if changes to log, harvest tree farm
			local timePassed = 0
			local blockType, blockModifier = T:getBlockType("forward")
			while true do
				T:clear()
				blockType, blockModifier = T:getBlockType("forward")
				if blockType == "minecraft:sapling" then
					print("Waiting for sapling to grow...")
					print(timePassed.." seconds passed...")
					sleep(10)
					timePassed = timePassed + 10
				elseif blockType == "minecraft:log" or blockType == "minecraft:log2" then
					harvestAutoTreeFarm()
					plantAutoTreeFarm()
					timePassed = 0
					-- wait for next sapling growth
				else
					print("No log or sapling in front..")
					print("terminating program")
					break
				end
			end
		else
			createNew = true
		end
		if createNew then
			print("On ground. Creating tree farm...")
			checkFuelNeeded(300)
			T:checkInventoryForItem({"minecraft:chest"}, {3})
			T:checkInventoryForItem({"minecraft:dirt"}, {64})
			T:checkInventoryForItem({"minecraft:cobblestone"}, {128})
			T:checkInventoryForItem({"minecraft:water_bucket"}, {2})
			T:checkInventoryForItem({"minecraft:hopper"}, {1})
			T:checkInventoryForItem({"minecraft:torch"}, {6})
			T:checkInventoryForItem({"minecraft:sapling"}, {6})
			print(thanks)
			os.sleep(2)    -- pause for 2 secs to allow time to press esc
			print("Creating automatic tree farm...")
			createAutoTreeFarm()
			-- plant saplings
			-- wait for trees
			-- harvest tree farm
		end
	elseif choice == 32 then	-- Create wheat farm
		-- needs a diamond hoe and axe either in the inventory, or already equipped (NOT together)
		local itemEquipped = T:getEquipped("left") --tools already swapped to put crafting table on the right
		if itemEquipped == "minecraft:diamond_hoe" then
			if T:getItemSlot("minecraft:diamond_pickaxe", 0) == 0 then
				T:checkInventoryForItem({"minecraft:diamond_pickaxe"}, {1})
			end
			-- ensure pickaxe is equipped
			T:equip("left", "minecraft:diamond_pickaxe", 0)
			print("\nDO NOT REMOVE THE HOE FROM MY INVENTORY!")
			sleep(2)
		end
		local clearFirst = false
		local decision  = ""
		local fuelNeeded = 0
		while decision ~= "y" and decision ~= "n" do
			T:clear()
			print("Is there a clear flat area at least\n9 x 12 in front of me? (y/n)\n\n(Area will be cleared first if not)")
			decision = read()
		end
		if decision == "n" then -- area needs clearing
			clearFirst = true
			checkFuelNeeded(480)
		else
			checkFuelNeeded(480)
			T:checkInventoryForItem({"minecraft:dirt"}, {64})
		end
		T:checkInventoryForItem({"minecraft:cobblestone"}, {40})
		T:checkInventoryForItem({"minecraft:water_bucket"}, {2})
		T:checkInventoryForItem({"minecraft:chest"}, {2})
		T:checkInventoryForItem({"minecraft:hopper"}, {1})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Creating 8x8 Wheat farm")
		createWheatFarm(clearFirst)
	elseif choice == 33 then	-- Plant wheat farm
		-- needs a diamond hoe either in the inventory, or already equipped (NOT together)
		local itemEquipped = T:getEquipped("left") --tools already swapped to put crafting table on the right
		local itemAvailable = ""
		if itemEquipped == "minecraft:diamond_pickaxe" then
			if T:getItemSlot("minecraft:diamond_hoe", 0) == 0 then
				T:checkInventoryForItem({"minecraft:diamond_hoe"}, {1})
			end
			itemAvailable = "minecraft:diamond_hoe"
		end
		--ensure hoe is equipped
		if itemEquipped ~= "minecraft:diamond_hoe" then
			T:equip("left", "minecraft:diamond_hoe", 0)
			print("\nDO NOT REMOVE THE PICKAXE FROM MY INVENTORY!")
			sleep(2)
		end
		checkFuelNeeded(180)
		T:checkInventoryForItem({"minecraft:wheat_seeds"}, {8})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Planting 8x8 Wheat farm")
		plantWheatFarm()
	elseif choice == 34 then	-- Harvest wheat farm
		checkFuelNeeded(180)
		T:checkInventoryForItem({"minecraft:bucket", "minecraft:water_bucket"}, {1, 1})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Harvesting 8x8 Wheat farm")
		harvestWheatFarm()
	elseif choice == 41 then --harvest obsidian
		checkFuelNeeded(width * length * 3)
		T:checkInventoryForItem({"minecraft:cobblestone"}, {width * length})
		print(thanks)
		sleep(2)
		print("Harvesting obsidian area: size "..width.. " x "..length)
		harvestObsidian(width, length)
	elseif choice == 42 then --build nether portal
		checkFuelNeeded(20)
		T:checkInventoryForItem({"minecraft:obsidian"}, {10})
		T:checkInventoryForItem({"minecraft:cobblestone"}, {8})
		print(thanks)
		sleep(2)
		print("Building Nether portal")
		buildPortal()
	elseif choice == 43 then --demolish nether portal
		checkFuelNeeded(20)
		print("Demolishing Nether portal")
		demolishPortal()
	elseif choice == 51 then	-- bridge over void/water/lava
		checkFuelNeeded((size + 1) * 2)
		T:checkInventoryForItem({"minecraft:cobblestone",  "minecraft:dirt"}, {size * 2, size * 2})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Building bridge ".. size.." blocks")
		createBridge(size)
	elseif choice == 52 then	-- covered walkway
		checkFuelNeeded((size + 1) * 2)
		T:checkInventoryForItem({"minecraft:cobblestone", "minecraft:dirt"}, {size * 2, size * 2})
		T:checkInventoryForItem({"minecraft:torch"}, {math.ceil(size / 8)})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Building bridge ".. size.." blocks")
		createWalkway(size)
	elseif choice == 53 then	-- continuous path over void/water/lava
		checkFuelNeeded(512) -- allow for 512 length
		T:checkInventoryForItem({"minecraft:cobblestone",  "minecraft:dirt"}, {64, 64}, false)
		T:checkInventoryForItem({"minecraft:torch"}, {64}, false)
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Building continuous path")
		createPath()
	elseif choice == 54 or choice == 55 then	-- canal management
		checkFuelNeeded(1024) -- allow for 1024 length
		--T:checkInventoryForItem({"minecraft:chest"}, {1})
		T:checkInventoryForItem({"minecraft:cobblestone",  "minecraft:dirt"}, {256, 256})
		if choice == 54 then
			T:checkInventoryForItem({"minecraft:torch"}, {64}, false)
		else --right side, flood canal
			T:checkInventoryForItem({"minecraft:water_bucket"}, {3})
		end
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		print("Building canal")
		createCanal(choice, size, length) -- eg 55, 312, 1 = complete a canal 312 blocks long on top of the wall
	elseif choice == 61 then	--  block path over water
		checkFuelNeeded(size + 24) -- allow for 88 moves
		T:checkInventoryForItem({"minecraft:cobblestone"}, {88})
		T:checkInventoryForItem({"minecraft:stone"}, {1})
		T:checkInventoryForItem({"minecraft:torch"}, {8}, false)
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		createMobSpawnerBase(size)
	elseif choice == 62 then	-- mob spawner tower
		checkFuelNeeded(1500) -- allow for 1000 blocks +  moves
		T:checkInventoryForItem({"minecraft:chest"}, {2})
		T:checkInventoryForItem({"minecraft:hopper"}, {2})
		T:checkInventoryForItem({"minecraft:water_bucket"}, {2})
		T:checkInventoryForItem({"minecraft:cobblestone"}, {576})
		T:checkInventoryForItem({"minecraft:stone"}, {1})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		createMobSpawnerTower(size)
	elseif choice == 63 then	-- mob spawner tank 
		checkFuelNeeded(1000) -- allow for 500 blocks +  moves
		T:checkInventoryForItem({"minecraft:water_bucket"}, {2})
		T:checkInventoryForItem({"minecraft:cobblestone"}, {576})
		T:checkInventoryForItem({"minecraft:stone"}, {1})
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		createMobSpawnerTank()
	elseif choice == 64 then	-- mob spawner roof
		checkFuelNeeded(500) -- allow for 400 blocks +  moves
		T:checkInventoryForItem({"minecraft:cobblestone"}, {384})
		T:checkInventoryForItem({"minecraft:torch"}, {20}, false)
		print(thanks)
		os.sleep(2)    -- pause for 2 secs to allow time to press esc
		createMobSpawnerRoof()
	elseif choice == 71 then --Clear rectangle
		checkFuelNeeded(width * length)
		print("Clearing rectangle: size "..width.. " x "..length)
		clearRectangle(width, length)
	elseif choice == 72 then --Clear wall
		checkFuelNeeded(length * height)
		print("Recycling wall "..height.." blocks high")
		clearWall(1, length, height)
	elseif choice == 73 then --Clear single height perimeter wall
		checkFuelNeeded((width + length) * 2)
		print("Recycling wall section "..width.." x "..length)
		clearPerimeterWall(width, length, 1)
	elseif choice == 74 then --Clear floor and perimeter walls
		checkFuelNeeded((width * length) + ((width + length) * height))
		print("Recycling building and floor "..width.." x "..length.." height: "..height)
		clearBuilding(width, length, height, false)
	elseif  choice == 76 or choice == 87 then --Hollow structure
		checkFuelNeeded(width * length * height)
		print("Creating hollow cube "..width.." x "..length.." height: "..height)
		buildHollow(width, length, height)
	elseif  choice == 77 or choice == 88 then --solid structure
		checkFuelNeeded(width * length * height)
		T:checkInventoryForItem({"minecraft:cobblestone", "minecraft:dirt"}, {width * length * height, width * length * height}, false)
		print("Creating solid cube "..width.." x "..length.." height: "..height)
		buildSolid(width, length, height)
	elseif  choice == 78 then --remove hollow structure bottom up
		checkFuelNeeded(width * length * height)
		print("Removing structure "..width.." x "..length.." height: "..height)
		clearHollow(width, length, height)
	elseif  choice == 79 then --remove solid structure bottom up
		checkFuelNeeded(width * length * height)
		print("Removing structure "..width.." x "..length.." height: "..height)
		clearSolid(width, length, height)
	elseif choice == 81 then --build containing wall in water or lava
		checkFuelNeeded(length * length)
		T:checkInventoryForItem({"minecraft:cobblestone",  "minecraft:dirt"}, {1024, 1024}, false)
		print("Building retaining wall in lava/water. length"..length)
		buildRetainingWall(length, height)
	elseif choice == 82 then --drop sand
		checkFuelNeeded(100)
		T:checkInventoryForItem({"minecraft:sand"}, {1024}, false)
		print("Building sand wall. length: "..length)
		buildSandWall(length)
	elseif choice == 83 then --decapitate and drop sand
		checkFuelNeeded(length * width)
		T:checkInventoryForItem({"minecraft:sand"}, {768}, false)
		print("Decapiating structure. length: "..length.." width: "..width)
		decapitateBuilding(width, length)
	elseif choice == 84 then --harvest sand
		checkFuelNeeded(100)
		print("Digging sand. length: "..length)
		clearSandWall(length)
	elseif choice == 85 then --remove sand cube
		checkFuelNeeded(length * width * 4)
		print("Removing sand cube. length: "..length.." width: "..width)
		clearSandCube(width, length)
	elseif choice == 86 then --remove floor and walls
		checkFuelNeeded(length * width * 4)
		print("Demolishing structure. length: "..length.." width: "..width)
		demolishBuilding(width, length)
	--elseif choice == 87 then check 76
	--elseif choice == 88 then check 77
	elseif choice == 91 then --place redstone torch level or downward slope
		checkFuelNeeded(10)
		local userChoice = T:checkInventoryForItem({"userChoice"}, {1})
		T:checkInventoryForItem({"minecraft:redstone_torch"}, {1})
		print("Placing redstone torch on ".. userChoice)
		placeRedstoneTorch("level", userChoice)
	elseif choice == 92 then --place redstone torch on upward slope
		checkFuelNeeded(10)
		local userChoice = T:checkInventoryForItem({"userChoice"}, {1})
		T:checkInventoryForItem({"minecraft:redstone_torch"}, {1})
		print("Placing redstone torch and ".. userChoice)
		placeRedstoneTorch("up", userChoice)
	elseif choice == 93 then --build downward slope
		checkFuelNeeded(height * 2)
		local userChoice = T:checkInventoryForItem({"userChoice"}, {height})
		T:checkInventoryForItem({"minecraft:redstone_torch"}, {math.ceil(height / 3)}, false)
		print("Building downward slope with ".. userChoice)
		createRailwayDown(userChoice, height)
	elseif choice == 94 then --build upward slope
		checkFuelNeeded(height * 2)
		local userChoice = T:checkInventoryForItem({"userChoice"}, {height + math.ceil(height / 3)})
		T:checkInventoryForItem({"minecraft:redstone_torch"}, {math.ceil(height / 3)}, false)
		print("Building upward slope with ".. userChoice)
		createRailwayUp(userChoice, height)
	end
	return retValue
end

function buildPortal()
	T:go("D1x1")
	T:place("minecraft:cobblestone", 0, "forward", true)
	for i = 1, 3 do
		T:go("U1x1")
		T:place("minecraft:obsidian", 0, "forward", true)
	end
	T:go("U1x1")
	T:place("minecraft:cobblestone", 0, "forward", true)
	for i = 1, 2 do
		T:go("R1F1L1x1")
		T:place("minecraft:obsidian", 0, "forward", true)
	end
	T:go("R1F1L1x1")
	T:place("minecraft:cobblestone", 0, "forward", true)
	for i = 1, 3 do
		T:go("D1x1")
		T:place("minecraft:obsidian", 0, "forward", true)
	end
	T:go("D1x1")
	T:place("minecraft:cobblestone", 0, "forward", true)
	for i = 1, 2 do
		T:go("L1F1R1x1")
		T:place("minecraft:obsidian", 0, "forward", true)
	end
	T:go("U1L1F1R1")
end

function buildHollow(width, length, height)
	--should be in bottom left corner at top of structure
	-- dig out blocks in front and place to the left side
	--go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	-- go @# = place any block up/forward/down # = 0/1/2
	for h = 1, height do
		for i = 1, length - 1 do
			T:go("L1@1R1F1", false, 0, true, false)
		end
		T:go("L1@1R2", false, 0, true, false)
		for i = 1, width - 1 do
			T:go("L1@1R1F1", false, 0, true, false)
		end
		T:go("L1@1R2", false, 0, true, false)
		for i = 1, length - 1 do
			T:go("L1@1R1F1", false, 0, true, false)
		end
		T:go("L1@1R2", false, 0, true, false)
		for i = 1, width - 1 do
			T:go("L1@1R1F1", false, 0, true, false)
		end
		T:go("L1@1R2", false, 0, true, false)
		-- hollowed out, now clear water/ blocks still present
		clearRectangle(width, length)
		if h < height then
			T:down(1)
		end
	end
end

function buildRetainingWall(length, height)
	if height <= 0 then
		height = 30
	end
	local y = 1
	-- go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	-- start at surface, move back 1 block
	-- each iteration completes 3 columns
	local numBlocks = T:getSolidBlockCount()
	if length == 1 then --single column
		while not turtle.detectDown() do
			T:down(1)
			y = y + 1
		end
		for i = 1, y - 1  do
			T:go("U1C2", false, 0, true, false)
		end
	elseif length == 2 then--down then up
		T:back(1)
		while not turtle.detectDown() do
			T:go("C1D1", false, 0, true, false)
			y = y + 1
		end
		T:forward(1)
		while not turtle.detectDown() do
			T:down(1)
			y = y + 1
		end
		T:go("B1C1", false, 0, true, false) 
		for i = 1, y - 1 do
			T:go("U1C2", false, 0, true, false)
		end
		T:go("C1", false, 0, true, false)
	else -- length 3 or more eg 3,22; 11
		local remain = length % 3 -- 0; 1; 2 only possible results
		length = length - remain -- 3-0=3; 4-1=3; 5-2=3; 6-0=6
		for i = 3, length, 3 do -- 3, 6, 9, 12 etc
			numBlocks = T:getSolidBlockCount()
			if numBlocks < height * 3 then
				--ask player for more
				T:checkInventoryForItem({"minecraft:cobblestone",  "minecraft:dirt"}, {height * 3, height * 3}, false)
			end
			T:go("B1C1")
			if i > 3 then -- second iteration
				T:go("B1C1")
			end
			-- place blocks forward while descending
			while not turtle.detectDown() do
				T:go("C1D1", false, 0, true, false)
				y = y + 1
			end
			-- may be higher than column in front
			T:forward(1)
			while not turtle.detectDown() do
				T:down(1)
				y = y + 1
			end
			while not turtle.detectUp() do	
				T:go("U1C2")
				y = y - 1
			end
			T:go("B1C1B1", false, 0, true, false) 
			-- return to surface, placing forward and below
			for i = 1, y - 1 do
				T:go("C1U1C2", false, 0, true, false)
			end
			-- put missing block down
			T:go("C1", false, 0, true, false)
			y = 1 -- reset counter
		end
		if remain == 1 then -- 1 more column
			y = 1
			T:back(1)			
			while not turtle.detectDown() do
				T:down(1)
				y = y + 1
			end
			for i = 1, y - 1 do
				T:go("U1C2", false, 0, true, false)
			end
			-- put missing block down
			T:go("C1", false, 0, true, false)
		elseif remain == 2 then -- 2 cols
			y = 1
			T:back(1)
			while not turtle.detectDown() do
				T:go("C1D1", false, 0, true, false)
				y = y + 1
			end
			T:forward(1)
			while not turtle.detectDown() do
				T:down(1)
				y = y + 1
			end
			T:go("B1C1", false, 0, true, false) 
			for i = 1, y - 1 do
				T:go("U1C2", false, 0, true, false)
			end
			-- put missing block down
			T:go("C1", false, 0, true, false)
		end
	end
end

function buildSandWall(length)
	length = length or 0
	local success = true
	if length > 0 then
		for i = 1, length - 1 do
			success = dropSand()
			T:forward(1, false)
		end
		success = dropSand()
	else
		while not turtle.detectDown() do -- over water
			while not turtle.detectDown() do -- over water
				success = dropSand()
			end
			if success then
				T:forward(1, false)
			else -- out of sand
				break
			end
		end
	end
end

function buildSolid(width, length, height)
	for i = 1, width do --width could be 1, 2, 3 etc
		buildRetainingWall(length, height)
		if i < width then --width = 2 or more
			if i == 1 or i % 2 == 1 then -- iteration 1, 3, 5
				T:go("L1F1L2C1R1", false, 0, true, false)
			else
				T:go("R1F1R2C1L1", false, 0, true, false)
			end
		end
	end
end

function clearArea(width, length, useDirt)
	if useDirt == nil then
		useDirt = true
	end
	local evenWidth = false
	local evenHeight = false
	local loopWidth
	-- go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	if width % 2 == 0 then
		evenWidth = true
		loopWidth = width / 2
	else
		loopWidth = math.ceil(width / 2)
	end
	if length % 2 == 0 then
		evenHeight = true
	end
	-- clear an area between 2 x 4 and 32 x 32
	-- if width is even no, then complete the up/down run
	-- if width odd no then finish at top of up run and reverse
	-- should be on flat ground, check voids below, harvest trees
	for x = 1, loopWidth do
		-- Clear first column (up)
		for y = 1, length do
			if useDirt then
				if not turtle.detectDown() then
					T:place("minecraft:dirt", -1, "down", true)
				else --if not water, dirt, grass , stone then replace with dirt
					blockType, blockModifier = T:getBlockType("down")
					if blockType ~= "minecraft:grass" and blockType ~= "minecraft:dirt" and blockType ~= "minecraft:stone" and blockType ~= "minecraft:water" then
						turtle.digDown()
						T:place("minecraft:dirt", -1, "down", true)
					end
				end
			end
			blockType, blockModifier = T:getBlockType("forward")
			if blockType == "minecraft:log" or blockType == "minecraft:log2" then -- tree in front, so harvest it
				T:harvestTree() --automatically moves forward 1 block
				if y == length then -- move back 1 if already at max length
					T:back(1)
				end
			else
				if y < length then
					T:go("F1+1", false,0,false,true)
				end
			end	
		end
		-- clear second column (down)
		if x < loopWidth or (x == loopWidth and evenWidth) then -- go down if on width 2,4,6,8 etc
			T:go("R1F1+1R1", false,0,false,true)
			for y = 1, length do
				if useDirt then
					if not turtle.detectDown() then
						T:place("minecraft:dirt", -1, "down", true)
					else
						blockType, blockModifier = T:getBlockType("down")
						if blockType ~= "minecraft:grass" and blockType ~= "minecraft:dirt" and blockType ~= "minecraft:stone" and blockType ~= "minecraft:water" then
							turtle.digDown()
							T:place("minecraft:dirt", -1, "down", true)
						end
					end
				end
				blockType, blockModifier = T:getBlockType("forward")
				if blockType == "minecraft:log" or blockType == "minecraft:log2" then -- tree in front, so harvest it
					T:harvestTree()
					if y == length then
						T:back(1)
					end
				else
					if y < length then
						T:go("F1+1", false,0,false,true)
					end
				end	
			end
			if x < loopWidth then 
				T:go("L1F1+1L1", false,0,false,true)
			else
				T:turnRight(1)
				T:forward(width - 1)
				T:turnRight(1)
			end
		else -- equals width but is 1,3,5,7 etc
			T:turnLeft(2) --turn round 180
			T:forward(length - 1)
			T:turnRight(1)
			T:forward(width - 1)
			T:turnRight(1)
		end
	end
end

function clearBuilding(width, length, height, withCeiling)
	--clear floor
	clearRectangle(width, length)
	T:up(1)
	if withCeiling then
		clearPerimeterWall(width, length, height - 2)
		T:up(1)
		clearRectangle(width, length)
		T:down(1)
	else
		clearPerimeterWall(width, length, height - 1)
	end
	T:down(height - 1)
end

function clearHollow(width, length, height)
	if height == 0 then
		--need to check if anything above except bedrock
		local totalItemCount = 0
		repeat
			totalItemCount = T:getTotalItemCount()
			clearPerimeterWall(width, length, 1)
			T:up(1)
			height = height + 1
		until T:getTotalItemCount() == totalItemCount -- nothing collected or full inventory
	else
		clearPerimeterWall(width, length, height)
	end
	T:down(height)
end

function clearSolid(width, length, height)
	if height == 0 then
		--need to check if anything above except bedrock
		local totalItemCount = 0
		repeat
			totalItemCount = T:getTotalItemCount()
			clearRectangle(width, length)
			T:up(1)
			height = height + 1
		until T:getTotalItemCount() == totalItemCount -- nothing collected or full inventory
	else
		for i = 1, height do
			clearRectangle(width, length)
			T:up(1)
		end
		
	end
	T:down(height)
end

function clearPerimeterWall(width, length, height)
	-- go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	-- if height <= 0 then stop when nothing above
	if height > 0 then
		for i = 1, height do
			T:go("F"..tostring(length - 1)..
				 "R1F"..tostring(width - 1)..
				 "R1F"..tostring(length - 1)..
				 "R1F"..tostring(width - 1)..
				 "R1", false, 0, false, false)
			if i < height then
				T:up(1)
			end
		end
	else
		repeat
			T:go("F"..tostring(length - 1)..
				 "R1F"..tostring(width - 1)..
				 "R1F"..tostring(length - 1)..
				 "R1F"..tostring(width - 1)..
				 "R1", false, 0, false, false)
			if turtle.detectUp() then
				T:up(1)
			end
		until not turtle.detectUp()
	end
end

function clearRectangle(width, length)
	-- could be 1 wide x xx lenght (trench) up and return
	-- could be 2+ x 2+
	-- even no of runs return after last run
	-- odd no of runs forward, back, forward, reverse and return
	local directReturn = true
	if width % 2 == 1 then
		directReturn = false
	end
	if width == 1 then -- trench ahead
		T:go("F"..length - 1 .."R2F"..length - 1 .."R2")
	else
		if directReturn then -- width = 2,4,6,8 etc
			for i = 1, width, 2 do -- i = 1,3,5,7 etc
				T:go("F"..length - 1 .."R1F1R1F"..length - 1)
				if i < width - 2 then -- eg width = 8, i compares with 6: 1, 3, 5, 7
					T:go("L1F1L1")
				end
			end
			T:go("R1F"..width - 1 .."R1")
		else -- width = 3, 5, 7, 9 eg width 7
			for i = 1, width - 1, 2 do -- i = 1,3,5
				T:go("F"..length - 1 .."R1F1R1F"..length - 1 .."L1F1L1")
			end
			-- one more run then return
			T:go("F"..length - 1 .."R2F"..length - 1 .."R1F"..width - 1 .."R1")
		end
	end
end

function clearSandWall(length)
	--dig down while on top of sand
	while T:getBlockType("down") == "minecraft:sand" do
		T:down(1)
	end
	-- repeat length times
	for i = 1, length do
		--if sand in front, dig
		while turtle.detect() do
			if T:getBlockType("forward") == "minecraft:sand" then
				T:dig("forward")
			else --solid block, not sand so move up
				T:up(1)
			end
		end
		--move forward
		T:forward(1)
		while T:getBlockType("down") == "minecraft:sand" do
			T:down(1)
		end
	end
end

function clearSandCube(width, length)
	--go down to bottom of sand
	while T:getBlockType("down") == "minecraft:sand" do
		T:down(1)
	end
	clearBuilding(width, length, 0, false)
end

function clearWall(width, length, height)
	local evenHeight = false
	local atStart = true
	local drop = height - 2
	-- go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	if height % 2 == 0 then
		evenHeight = true
	end

	-- dig along and up for specified length
	if evenHeight then --2, 4 , 6 etc
		for h = 2, height, 2 do
			for i = 1, length - 1 do
				T:go("x0F1", false, 0, false, false)
			end
			if h < height then
				T:go("R2U2", false, 0, false, false)
			end
			atStart = not atStart
		end
	else
		drop = height - 1
		for h = 1, height, 2 do
			if h == height then
				T:go("F"..tostring(length - 1), false, 0, false, false)
			else
				for i = 1, length - 1 do
					T:go("x0F1", false, 0, false, false)
				end
			end
			atStart = not atStart
			if h < height then
				T:go("R2U2", false, 0, false, false)
			end
		end
	end
	if evenHeight then
		T:go("x0", false, 0, false, false)
	end
	T:go("R2D"..drop, false, 0, false, false)
	if not atStart then
		T:go("F"..tostring(length - 1).."R2", false, 0, false, false)
	end
end

function createAutoTreeFarm()
	T:clear()
	print("Clear the area first? (y/n)")
	local response = read()
	if response == "y" then
		createWheatFarm(true, 11, 14)
	else
		createWheatFarm(false)
	end
	-- flood area to collect saplings
	-- refill water buckets
	T:forward(1)
	for i = 1, 2 do
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down", false)
	end
	T:go("F1U1F10R1F8R2")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:forward(2)
	T:place("minecraft:water_bucket", -1, "down", false)
	T:go("F5L1F10D1")
	for i = 1, 2 do
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down", false)
	end
	T:go("U1R2F10R1F3R2")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:forward(2)
	T:place("minecraft:water_bucket", -1, "down", false)
	T:go("F1L1F10D1R2")
	for i = 1, 2 do
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down", false)
	end
	T:go("U1F10R1")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:go("F2R1U1F2")
	for i = 1, 3 do
		T:place("minecraft:dirt", -1, "down", false)
		T:up(1)
		T:place("minecraft:sapling", -1, "down", false)
		T:forward(1)
		T:down(1)
		T:place("minecraft:torch", -1, "down", false)
		T:forward(1)
	end
	T:go("L1F3L1F2")
	for i = 1, 3 do
		T:place("minecraft:dirt", -1, "down", false)
		T:up(1)
		T:place("minecraft:sapling", -1, "down", false)
		T:forward(1)
		T:down(1)
		T:place("minecraft:torch", -1, "down", false)
		T:forward(1)
	end
	T:go("L1F4L1F7L1F1R1")
	T:place("minecraft:chest", -1, "forward", false)
	T:turnLeft(2)
end

function createBridge(numBlocks)
	for i = 1, numBlocks do
		T:go("m1")
	end
	T:go("R1F1R1")
	for i = 1, numBlocks do
		T:go("m1")
	end
end

function createCanal(choice, size, length)
	-- choice = 54/55: left/right side
	-- size = 0-1024 o = continuousheight = 0/1 0 = floor, 1 = wall
	-- T:place(blockType, damageNo, direction, leaveExisting)
	-- T:go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	-- T:harvestTree(extend, craftChest, direction)
	-- start with forward run:
	local doContinue = true
	local numBlocks  = 0
	local doTunnel = false
	local requestTunnel = false
	local maxLength = 1024
	if size ~= 0 then
		maxLength = size
	end
	local blockType, modifier
	-- if height = 0 then already at correct height on canal floor
		-- check block below, block to left and block above, move forward tunnelling
		-- if entering water then move up, onto canal wall and continue pathway
		-- if 55 and tunnelling then flood canal
	-- else height = 1 then above water and on path across
		-- move forward, checking for water below
		-- if water finishes, move into canal, drop down and continue tunnelling
	if choice == 54 then -- left side
		while doContinue and numBlocks < maxLength do
			if height == 0 then -- canal floor
				blockType, modifier = T:getBlockType("down")
				if blockType == nil or blockType == "minecraft:lava" then -- air or lava below, so place block
					T:place("minecraft:cobblestone", -1, "down", false)
				end
				-- place side block
				T:go("L1C1R1", false , 0, true, true)
				-- check above
				blockType, modifier = T:getBlockType("up")
				if blockType == "minecraft:log" or blockType == "minecraft:log2" then
					T:harvestTree(false, false, "up")
				elseif blockType == "minecraft:lava" or blockType == "minecraft:water" then
					T:up(1)
					T:place("minecraft:cobblestone", -1, "up", false)
					T:down(1)
				else --solid block or air above
					if blockType ~= nil then
						T:dig("up")
					end
				end
				-- check if block in front is water source
				blockType, modifier = T:getBlockType("forward")
				if blockType == "minecraft:water" and modifier == 0 then -- source block in front could be lake/ocean
					-- move up, to left and continue as height = 1
					T:go("U1L1F1R1")
					height = 1
				else
					T:forward(1, true)
					numBlocks = numBlocks + 1
				end
			else -- height = 1, on canal wall
				numBlocks = numBlocks + createPath(0, true)
				-- if path finished, then move back to canal floor and continue tunnelling
				T:go("R1F1D1L1")
				height = 0
			end
		end
	else -- right side
		-- assume left side already under construction
		local poolCreated = false
		while doContinue and numBlocks < maxLength do
			if height == 0 then-- canal floor
				-- create first infinity pool
				if not poolCreated then
					T:up(1)
					T:place("minecraft:water_bucket", -1, "down", false)
					T:go("L1F1R1")
					T:place("minecraft:water_bucket", -1, "down", false)
					T:forward(1)
					T:place("minecraft:water_bucket", -1, "down", false)
					T:back(1)
					-- refill buckets
					for j = 1, 3 do
						T:place("minecraft:bucket", -1, "down", false)
						sleep(0,5)
					end
					T:go("R1F1L1F2", false , 0, true, false)
					T:down(1)
					poolCreated = true
				end
				blockType, modifier = T:getBlockType("down")
				if blockType == nil or blockType == "minecraft:lava" 
				   or blockType == "minecraft:water" or blockType == "minecraft:flowing_water" then -- air, water or lava below, so place block
					T:place("minecraft:cobblestone", -1, "down", false)
				end
				-- place side block
				T:go("R1C1L1", false , 0, true, false)
				T:up(1)
				blockType, modifier = T:getBlockType("up")
				if blockType == "minecraft:log" or blockType == "minecraft:log2" then
					T:harvestTree(false, false, "up")
				elseif blockType == "minecraft:lava" or blockType == "minecraft:water" then
					T:place("minecraft:cobblestone", -1, "up", false)
				end
				T:place("minecraft:water_bucket", -1, "down", false)
				for j = 1, 2 do
					T:forward(1)
					blockType, modifier = T:getBlockType("up")
					if blockType == "minecraft:log" or blockType == "minecraft:log2" then
						T:harvestTree(false, false, "up")
					elseif blockType == "minecraft:lava" or blockType == "minecraft:water" then
						T:place("minecraft:cobblestone", -1, "up", false)
					end
					-- at ceiling level
					T:go("D1R1C1L1", false, 0, true, false)
					blockType, modifier = T:getBlockType("down")
					if blockType == nil or blockType == "minecraft:lava" 
					   or blockType == "minecraft:water" or blockType == "minecraft:flowing_water" then -- air, water or lava below, so place block
						T:place("minecraft:cobblestone", -1, "down", false)
					end
					-- check if block in front is water source
					blockType, modifier = T:getBlockType("forward")
					T:up(1)
					T:place("minecraft:water_bucket", -1, "down", false)
					if blockType == "minecraft:water" and modifier == 0 then -- source block in front could be lake/ocean
						-- move to right and continue as height = 1
						T:go("R1F1L1")
						height = 1
						break	
					end
				end
				if height == 0 then
					T:back(2)
					for j = 1, 3 do
						T:place("minecraft:bucket", -1, "down", false)
						sleep(0,5)
					end
					T:go("F3D1", false, 0, true, false)
				end
			else -- height = 1: on wall 
				numBlocks = numBlocks + createPath(0, true)
				-- if path finished, then move back to canal floor and continue tunnelling
				T:go("L1F1L1F1") -- facing backwards, collect water
				for j = 1, 3 do
					T:place("minecraft:bucket", -1, "down", false)
					sleep(0,5)
				end
				T:go("R2F1D1") --canal floor
				height = 0
			end
		end
	end
end

function createMobSpawnerBase(pathLength)
	if pathLength > 0 then
		print("Building path to mob spawner base")
		createPath(pathLength)
		T:back(1)
	end
	T:place("minecraft:stone", -1, "down", true)
	T:go("R1F1L1")
	createPath(8)
	T:go("L1F1L1F1")
	createPath(8)
	T:go("R1F1R1F1")
	createPath(8)
	T:go("L1F1L1F1")
	createPath(8)
	T:go("L1F2L1F1")
end

function createMobSpawnerTower(height)	
	height = height or 2
	print("Building mob spawner base")
	-- assume placed at sea level on stone block (andesite / granite / diorite)
	--layers 2, 3 (layer 1 done at base construction)
	T:go("U1F7H2L1F1H2R1F2D1R2P1L1F1R1P1R2U1")
	for i = 1, 8 do
		T:go("C2R1C1L1F1")
	end
	T:go("L1F1L2C1R1F1R2C1R2")
	for i = 1, 8 do
		T:go("C2R1C1L1F1")
	end
	T:go("U1R2F8R1")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:go("F1R1")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:forward(16)
	T:go("R1F1D2")
	for i = 1, 2 do
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down", false)
	end
	T:go("R1F2")
	for i = 1, 2 do
		T:go("C1R1C1R2C1R1U1")
	end
	-- height of tower
	height = math.ceil(height / 2)
	for i = 1, height do
		T:go("C1U1C1R1C1R1C1R1C1R1U1")
	end
	-- create platform for player
	T:go("R2F1L1C1R1C1R1C1U1C1L1C1L1C1L1F1L1C!R2C1L1U1F1")
	-- place stone marker
	T:place("minecraft:stone", -1, "down")
	-- will need to move back before completing
end

function createMobSpawnerTank()
	--layer 1 of tower + walkway
	-- move back 1 block before continuing with tower top and walkway
	T:go("R2F1R2")
	T:go("C1U2R1F1L1") -- now dropping cobble from above
	T:go("m10L1F1L1")
	T:go("m9R1F1L1F1C2F1L1F1C2L1F1")
	--layer 2
	T:go("U1F1C2R1F1C2F1L1F1m8L1F3L1m8F2L1F1L1")
	--layer 3
	T:go("U1R1F1C2L1F1C2")
	T:go("F1R1F1L1C2F1C2F1L1F1C2")
	T:go("F1C2F1L1F1C2F1C2F2C2F1")
	T:go("L1F1C2L1F2C2B1")
	--layer 4
	T:go("U1F1L1F1R2")
	for i = 1, 4 do
		T:go("F1C2F1C2F1L1")
	end
	T:go("F1R1F1R2")
	--layer 5
	T:go("U1R2F1m7L1F1L1C2F1C2F7C2F1C2")
	T:go("F1R1F1L1C2F1C2F1L1F1C2F1C2F1")
	T:go("L1F1C2F1C2F2C2L1F1L1F1C2R2F1R2")
	-- layer 6
	T:go("U1R2F9C2L1F1C2F1L1F1C2F1L1F1C2R1F8L1F2R2")
	for i = 1, 4 do
		T:go("F1C2F1C2F1L1")
	end
	T:go("F1L1F1")
	T:place("minecraft:water_bucket", -1, "down")
	T:go("R1F1L1")
	T:place("minecraft:water_bucket", -1, "down")
	T:go("R2F2R1F1R1")
	-- layer 7
	T:go("U1R2F8L1F2C2L1F1L1F1C2R1F7C2L1F2R1C2F1R1")
	for i = 1, 4 do
		T:go("F1C2F1C2F1L1")
	end
	T:go("F1R1F1R2")
	T:go("F2")
	-- place stone inside column, ready for temp water source
	T:place("minecraft:stone", -1, "down", false)
	
	-- layer 8
	-- make temp water source in centre. destroy in createMobSpawnerRoof()
	T:go("F1C2R1F1C2R1F1C2F1R1F2U1R2")
	-- spiral construction
	for j = 3, 9, 2 do
		for i = 1, 4 do
			if i < 4 then
				T:go("m"..j.."L1")
			else
				T:go("m"..j.."F1R1F1L2")
			end
		end
	end
	-- fill water source
	T:go("F5L1F5")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:go("F1R1F1R1")
	T:place("minecraft:water_bucket", -1, "down", false)
	T:go("F5m4F2C2F1R1F1C2F1R1F1C2F1R1F1L1C2F1m4")
	T:go("F8F2m3R1F1R1m3")
	T:go("F5L1F5m3R1F1R1m3")
	T:go("F9F2m3R1F1R1m3")
	-- layer 9
	T:up(1)
	for i = 1, 4 do
		T:go("L1F1L1m3R1F1R1m3L1F1L1m3R1F1R1m3F4")
		T:go("L1F1L1m7R1F1R1m7L1F1L1m7R1F1R1m7F1L1F1R1C2F1C2R1F4")
	end
	-- now add water
	T:go("F6")
	for i = 1, 4 do
		T:down(1)
		T:place("minecraft:bucket", -1, "down", false)
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down")
		T:go("U1F8R1")
		T:place("minecraft:water_bucket", -1, "down", false)
		T:go("F1R1")
		T:place("minecraft:water_bucket", -1, "down", false)
		T:go("F8L1")
	end
	for i = 1, 2 do
		T:down(1)
		T:place("minecraft:bucket", -1, "down", false)
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down", false)
		T:go("U1F4L1F4L1")
		T:place("minecraft:water_bucket", -1, "down", false)
		T:go("F9")
		T:place("minecraft:water_bucket", -1, "down", false)
		T:go("L1F5L1F4L2")
	end
	T:go("F9R1F10R1")
	-- layer 10 / 11
	for j = 1, 2 do
		T:go("U1F1m8L1F1C2F1R1F1C2F1R1F1C2F1R1F1R2m8F1R1")
		for i = 1, 3 do
			T:go("F1m17F1R1")
		end
	end
	T:go("F10R1F9D4")
end

function createMobSpawnerRoof()
	-- destroy water source first
	T:go("x2C1R1F1x2L1F1x2L1F1x2L1F1x2L2")
	T:go("U5L1F8L1F8L2") -- top left corner facing e
	T:go("m17R1m17R1m17R1m17") -- outer ring. ends facing n
	T:go("R1F2R1F1L1") -- facing e
	for i = 1, 4 do -- outer ring - 1 (with torches) ends facing e
		T:go("m6t1m3t1m5R1F1t1")
	end
	T:go("R1F1L1") -- facing e
	for i = 1, 4 do -- outer ring - 2 ends facing e
		T:go("m13R1m13R1m13R1m13")
	end
	T:go("R1F1L1") -- ends facing e
	T:go("m11R1m11R1m11R1m11") -- ends facing e
	T:go("R1F1R1F1L1F1")
	for i = 1, 4 do
		T:go("m8R1F1t1")
	end
	T:go("R1F1L1")
	T:go("m7R1m7R1m7R1m7")
	T:go("R1F1R1F1L1")
	T:go("m5R1m5R1m5R1m5")
	T:go("R1F1R1F1L1F1")
	for i = 1, 4 do
		T:go("m2R1F1t1")
	end
	T:go("R1F1L1")
	T:go("m1R1m1R1m1R1m1")
end

function createPath(length, isCanal)
	length = length or 0 --allow for choice of path length
	if isCanal == nil then
		isCanal = false
	end
	local numBlocks = 1
	local path = 0
	local distance = 0
	local torch = 0
	local continue = true
	local slot = 0
	T:forward(1)
	local blockType, blockModifier = T:getBlockType("down")
	while blockType == "minecraft:water" or blockType == "minecraft:lava" or blockType == nil do
		continue = true
		if not T:place("minecraft:cobblestone", -1, "down") then
			if not T:place("minecraft:dirt", -1, "down") then
				if not T:place("minecraft:end_stone", -1, "down") then
					continue = false -- stop if out of cobble / dirt
				end
			end
		end
		if continue then
			T:forward(1)
			numBlocks = numBlocks + 1
			blockType, blockModifier = T:getBlockType("down")
			distance = distance + 1
			torch = torch + 1
			slot = T:getItemSlot("minecraft:torch", -1)
			if torch == 8 and slot > 0 then
				torch = 0
				T:turnRight(2)
				T:place("minecraft:torch", -1, "forward", false)
				T:turnRight(2)
			end
		else
			break
		end
		path = path + 1
		if length > 0 and path >= length then
			break
		end
	end
	if continue and not isCanal then
		T:forward(1)
	end
	return numBlocks
end

function createLadder(destination, level)
	-- R# L# F# B# U# D# +0 -0 = Right, Left, Forward, Back, Up, Down, up while detect and return, down while not detect
	-- dig:			  x0,x1,x2 (up/fwd/down)
	-- suck:		  s0,s1,s2
	-- place chest:   H0,H1,H2 
	-- place sapling: S0,S1,S2
	-- place Torch:   T0,T1,T2
	-- place Hopper:  P0,P1,P2
	-- mine floor:	  m# = mine # blocks above and below, checking for valuable items below, and filling space with cobble or dirt
	-- mine ceiling:  M# = mine # blocks, checking for valuable items above, and filling space with cobble or dirt
	-- mine ceiling:  N# same as M but not mining block below unless valuable
	-- place:		  C,H,r,S,T,P = Cobble / cHest / DIrT / Sapling / Torch / hoPper in direction 0/1/2 (up/fwd/down) eg C2 = place cobble down
	local height = 0
	local ledge = 0
	if destination == "surface" then
		T:go("C1U1C1")
		for j = level - 2, 1, -1 do
			T:up(1)
			for i = 1, 4 do
				if i ~= 3 then
					T:go("C1R1")
				else
					T:turnRight(1)
				end
			end
			height = height + 1
		end
		-- at level 64. check if still blocks above
		while turtle.inspectUp() do
			T:up(1)
			for i = 1, 4 do
				if i ~= 3 then
					T:go("C1R1")
				else
					T:turnRight(1)
				end
			end
			height = height + 1
		end
		-- nothing above
		T:go("U1R2F1L2") -- face wall previously built
		for i = height, 1, -1 do
			ledge = ledge + 1
			if ledge >= 3 then
				ledge = 0
				T:place("minecraft:cobblestone", 0, "up")
			end
			-- Place cobble on 3 sides (if required)
			for j = 1, 4 do
				if j == 1 then -- place ladder on first side
					T:place("minecraft:ladder", 0, "forward", false)
				else
					T:place("minecraft:cobblestone", 0, "forward")
				end
				T:turnLeft(1)
			end
			T:down(1)
		end
	else -- ladder to bedrock
		-- dig shaft to bedrock and close all sides except facing
		-- create a working area at the base
		-- Return to surface facing towards player placing ladders
		repeat
			height = height + 1
			for i = 1, 4 do
				if i ~= 1 then
					T:place("minecraft:cobblestone", 0, "forward")
				end
				T:turnRight(1)
			end
		until not T:down(1)
		-- test to check if on safe level immediately above tallest bedrock
		height = T:findBedrockTop(height)
		
		-- In shaft, facing start direction, on lowest safe level
		-- create a square space round shaft base, end facing original shaft, 1 space back
		T:go("F1R1m1R1m2R1m2R1m2R1F1R1F1C1U1C1D1R2F1R2")
		ledge = 0
		local atBedrock = true
		for i = height, 0, -1 do
			if ledge >= 3 then
				ledge = 0
				T:place("minecraft:cobblestone", 0, "down")
			end
			-- Place cobble on 3 sides (if required)
			for j = 1, 4 do
				if j == 1 then -- place ladder on first side
					if atBedrock then
						atBedrock = false -- do not place ladder on bottom block
					else
						T:place("minecraft:ladder", 0, "forward", false)
					end
				else
					T:place("minecraft:cobblestone", 0, "forward")
				end
				T:turnLeft(1)
			end
			T:up(1)
			ledge = ledge + 1
		end
	end
end

function createMine()
	T:clear()	
	T:go("m32U1R2M16D1", true, 8) -- mine ground level, go up, reverse and mine ceiling to mid-point, drop to ground
	T:place("minecraft:chest", -1, "down", false) --place chest in ground
	T:up(1)	-- ready for emptyTrash() which moves down/up automatically
	T:emptyTrash("down")
	T:go("D1R1m16U1R2M16", true, 8) -- mine floor/ceiling of right side branch
	T:emptyTrash("down")
	T:go("D1m16U1R2M16", true, 8) -- mine floor/ceiling of left side branch
	T:emptyTrash("down")
	T:go("L1M15F1R1D1", true, 8) -- mine ceiling of entry coridoor, turn right
	T:go("n16R1n32R1n32R1n32R1n16U1", true, 8)-- mine floor of 36 x 36 square coridoor
	T:go("R1F16R2") --return to centre
	T:emptyTrash("down")
	T:go("F16R1") --return to entry shaft
	T:go("Q16R1Q32R1Q32R1Q32R1Q16x0F1R1", true, 8) --mine ceiling of 36x36 square coridoor. return to entry shaft + 1
	-- get rid of any remaining torches
	while T:getItemSlot("minecraft:torch", -1) > 0 do
		turtle.select(T:getItemSlot("minecraft:torch", -1))
		turtle.drop()
	end
	for i = 1, 8 do
		T:go("N32L1F1L1", true)
		T:dumpRefuse()
		T:go("N32R1F1R1", true)
		T:dumpRefuse()
	end
	T:go("R1F1R2C1R2F17L1") -- close gap in wall, return
	for i = 1, 8 do
		T:go("N32R1F1R1", true)
		T:dumpRefuse()
		T:go("N32L1F1L1", true)
		T:dumpRefuse()	
	end
	T:go("L1F1R2C1R2F16R1") -- close gap in wall, return
	T:clear()
	print("Mining operation complete")
end

function createRailwayDown(userChoice, drop)
	--make sure torch placed on lowest level
	-- 1 block not required
	-- 2 - 3 blocks 1 torch at base
	-- 4 - 6 blocks 2 torch
	-- 
	for i = 1, drop - 1 do
		T:go("F1D1")
		T:place(userChoice, -1, "down", false)
	end
end

function createRailwayUp(userChoice, up)
	for i = 1, up do
		T:place(userChoice, -1, "forward", false)
		T:go("U1F1")
	end
end

function createStaircase(destination, level)
	-- R# L# F# B# U# D# +0 -0 = Right, Left, Forward, Back, Up, Down, up while detect and return, down while not detect
	-- dig:			  x0,x1,x2 (up/fwd/down)
	-- suck:		  s0,s1,s2
	-- place chest:   H0,H1,H2 
	-- place sapling: S0,S1,S2
	-- place Torch:   T0,T1,T2
	-- place Hopper:  P0,P1,P2
	-- mine floor:	  m# = mine # blocks above and below, checking for valuable items below, and filling space with cobble or dirt
	-- mine ceiling:  M# = mine # blocks, checking for valuable items above, and filling space with cobble or dirt
	-- mine ceiling:  N# same as M but not mining block below unless valuable
	-- place:		  C,H,r,S,T,P,^ = Cobble / cHest / DIrT / Sapling / Torch / hoPper /stair in direction 0/1/2 (up/fwd/down) eg C2 = place cobble down
	
	-- 3| |B| |
	--   - - - 
	-- 2|A| |C|
	--   - - - 
	-- 1|^|D| |
	--   - - - 
	--   1 2 3 
	
	local height = level -- eg 64 at top or 5 at bedrock
	local numStairs = T:getItemCount("minecraft:stone_stairs", 0)
	local numStairsNeeded = 0
	if destination == "bedrock" then
		numStairsNeeded = math.ceil(level / 4) * 4
	else
		numStairsNeeded = math.ceil((64 - level) / 4) * 4
	end
	numStairsNeeded = numStairsNeeded - numStairs
	if numStairsNeeded >  40 then
		T:craft("minecraft:stone_stairs", 40)	-- max 40 so repeat
		numStairsNeeded = numStairsNeeded - 40
	end
	if numStairsNeeded >  0 then
		T:craft("minecraft:stone_stairs", numStairsNeeded)
	end
	if destination == "bedrock" then -- go down to bedrock
		while T:down() do
			height = height - 1
		end
		height = T:findBedrockTop(height) -- usually around 5
		T:go("R1F1R1")
	end
	local onGround = true
	local top = (math.ceil((64 - height) / 4) * 4) + 4

	for i = height, top, 4 do
		for x = 1, 4 do
			-- start 1,1,1, n
			-- stage A
			T:go("L1C1R1F1L1C1R1C1R1C1L1B1^1") --start:1,1,1,n stairs A on level 1, going back to 1,1,1,n
			if not onGround then
				-- stage A1
				T:go("L2C1L2") -- start 1,1,1,n fix corner on level 1 end: 1,1,1,n
			end
			-- stage B
			T:go("U1L1C1") -- end  1,1,1,w layer 2
			if not onGround then
				T:go("L1C1R1") -- end  1,1,1,w layer 2
			end
			-- stage C1
			T:go("R1F1L1C1R2C1L1B1")
			-- stage C2
			T:go("U1L1C1L1C1L2F1L1C1R2C1L1B1D1") -- end 1,1,2,n
			onGround = false
			-- stage D
			T:go("F2L1C1R1C1R1") -- 3,1,2,e
		end
	end
end

function createTreefarm(size)
	local blockType
	local blockModifier
	local length
	local width
	
	if size == 1 then
		length = 11
		width = 6
		clearArea(11, 11)
	else
		length = 19
		width = 10
		clearArea(19, 19)
	end
	-- now place dirt blocks and torches
	T:go("F2R1F2L1U1")
	for x = 1, (width - 2) / 2 do
		for y = 1, (length - 3) / 2 do
			T:place("minecraft:dirt", -1, "down", false)
			if y < (length - 3) / 2 then
				T:forward(1)
				T:place("minecraft:torch", -1, "down", false)
				T:forward(1)
			end
		end
		T:go("R1F2R1")
		for y = 1, (length - 3) / 2 do
			T:place("minecraft:dirt", -1, "down", false)
			if y < (length - 3) / 2 then
				T:forward(1)
				T:place("minecraft:torch", -1, "down", false)
				T:forward(1)
			end
		end
		if x < (width - 2) / 2 then
			T:go("L1F2L1")
		else
			T:go("R1F6")
			if size == 2 then
				T:go("F8")
			end
			T:go("R1B1")
		end
	end
end

function createWalkway(length)
	local lengthParts = math.floor(length / 8) -- eg 12/8 = 1
	local lastPart = length - (lengthParts * 8) -- eg 12 - (1 * 8) = 4
	T:up(1)
	for j = 1, lengthParts do
		T:go("M8")
	end
	if lastPart > 0 then
		T:go("M"..tostring(lastPart)) -- eg m4
	end
	T:go("R2D1")
	T:place("minecraft:torch", 0, "up", false)
	for j = 1, lengthParts do
		T:go("m8", true)
		T:place("minecraft:torch", 0, "up", false)
	end
	if lastPart > 0 then
		T:go("m"..tostring(lastPart), true) -- eg m4
	end
	T:go("R2")
end

function createWaterSource()
	T:go("F1D1") --move to corner and drop down
	for i = 1, 4 do
		T:go("L1C1L1C1L2C2F1R1")
	end
	T:go("U1")
	for i = 1, 2 do
		T:place("minecraft:water_bucket", -1, "down", false)
		T:go("F1R1F1R1")
	end
	-- refill water buckets
	for i = 1, 2 do
		sleep(0.5)
		T:place("minecraft:bucket", -1, "down", false)
	end
	-- end facing towards farm above lower left pond
end

function createWheatFarm(clearFirst, width, height)
	width = width or 11
	height = height or 14
	if clearFirst then
		clearArea(width, height)
		while turtle.down() do end
	end
	createWaterSource()
	-- place chest and hopper
	T:go("F3L1F1R2D1x2")
	T:place("minecraft:chest", -1, "down", false)
	T:go("F1D1F1R2")
	T:place("minecraft:hopper", -1, "forward", false)
	-- dig trench and ensure base is solid
	T:go("U1p2R2m7U1R2")
	T:place("minecraft:water_bucket", -1, "down", false) -- collection stream
	T:go("R2F1U1R1m1R1m9R1m9m1R1F1D2")
	T:go("m7U1R2") -- dig trench and ensure base is solid
	T:place("minecraft:water_bucket", -1, "down", false) -- watering stream
	T:go("U1B1m9R2F9R1m9F1R1F9L1F3R2D1") -- back to start
end

function decapitateBuilding(width, length)
	--clearRectangle with sand drop
	-- could be 1 wide x xx lenght (trench) up and return
	-- could be 2+ x 2+
	-- even no of runs return after last run
	-- odd no of runs forward, back, forward, reverse and return
	local success
	local directReturn = true
	if width % 2 == 1 then
		directReturn = false
	end
	if width == 1 then -- trench ahead, so fill then return
		for i = 1, length - 1 do
			success = dropSand()
			T:forward(1, false)
		end
		success = dropSand()
		T:go("R2F"..(length - 1).."R2")
	else --2 or more columns
		if directReturn then -- width = 2,4,6,8 etc
			for i = 1, width, 2 do -- i = 1,3,5,7 etc
				-- move along length, dropping sand
				for j = 1, length - 1 do
					success = dropSand()
					T:forward(1, false)
				end
				success = dropSand()
				T:go("R1F1R1") --turn right and return on next column
				for j = 1, length - 1 do
					success = dropSand()
					T:forward(1, false)
				end
				success = dropSand()
				if i < width - 2 then -- eg width = 8, i compares with 6: 1, 3, 5, 7
					T:go("L1F1L1")
				end
			end
			T:go("R1F"..width - 1 .."R1") --return home
		else
			for i = 1, width, 2 do -- i = 1,3,5,7 etc
				-- move along length, dropping sand
				for j = 1, length - 1 do
					success = dropSand()
					T:forward(1, false)
				end
				success = dropSand()
				T:go("R1F1R1") --turn right and return on next column
				for j = 1, length - 1 do
					success = dropSand()
					T:forward(1, false)
				end
				success = dropSand()
				T:go("L1F1L1")
			end
			-- one more run then return
			for j = 1, length - 1 do
				success = dropSand()
				T:forward(1, false)
			end
			success = dropSand()
			T:go("R2F"..length.."R1F"..width - 1 .."R1")
		end
	end
end

function demolishBuilding(width, length)
	-- start bottom left
	clearBuilding(width, length, 0, false)
end

function demolishPortal()
	if T:getBlockType("forward") == "minecraft:obsidian" then
		T:down(1)
	end
	T:go("x1U1x1U1x1U1x1U1x1")
	for i = 1, 3 do
		T:go("R1F1L1x1")
	end
	T:go("D1x1D1x1D1x1D1x1")
	T:go("L1F1R1x1L1F1R1x1")
end

function dropSand()
	local success, slot
	while not turtle.detectDown() do -- over water. will be infinite loop if out of sand
		success, slot = T:place("minecraft:sand", -1, "down", false)
		if not success then
			print("Out of sand. Add more to continue...")
			sleep(2)
		end
	end
	return true --will only get to this point if turtle.detectDown() = true
end

function harvestObsidian(width, length)
	local heightParts = math.floor(length / 8) -- eg 12/8 = 1
	local lastPart = length - (heightParts * 8) -- eg 12 - (1 * 8) = 4
	if width % 2 ~= 0 then
		width = width + 1
	end
	for y = 1, width do
		print("Mining column "..tostring(y).." of "..tostring(width))
		for j = 1, heightParts do
			T:go("m8")
		end
		if lastPart > 0 then
			T:go("m"..tostring(lastPart)) -- eg m4
		end
		-- width = tonumber(width)
		if y < width then
			if y % 2 == 0 then
				T:go("L1F1L1")
			else
				T:go("R1F1R1")
			end
		end
	end
end

function harvestRun(runLength)
	local blockType
	local blockModifier

	for i = 1, runLength do
		blockType, blockModifier = T:getBlockType("forward") -- store information about the block in front in a table
		if blockType == "minecraft:log" or blockType == "minecraft:log2" then -- tree in front, so harvest it
			T:harvestTree(true, false)
		else
			T:forward(1)			
		end	
	end
end	

function harvestAutoTreeFarm()
	local blockType, blockModifier
	for  j = 1, 2 do
		for i = 1, 3 do
			blockType, blockModifier = T:getBlockType("forward")
			if  blockType == "minecraft:log" or blockType == "minecraft:log2" then
				T:harvestTree(true, false)
				T:forward(1)
			elseif  blockType == "minecraft:sapling" then
				T:go("U1F2D1")
			else
				T:forward(1)
			end
		end
		if j == 1 then
			T:go("R1F3R1")
		else
			T:go("R1F3L1")
		end
	end
	T:dropItem("minecraft:log", 0, "forward")
	T:dropItem("minecraft:log2", 0, "forward")
	T:dropItem("minecraft:apple", 0, "forward")
	T:turnRight(2)
end

function placeRedstoneTorch(direction, userChoice)
	if direction == "level" then
		T:go("R1F1D2L2F1R1")
		--clsTurtle.place(self, blockType, damageNo, direction, leaveExisting)
		T:place(userChoice, -1, "forward", false)
		T:back(1)
		T:place("minecraft:redstone_torch", -1, "forward", true)
		T:go("R1F1L1F1U2L1F1R1")
	elseif direction == "up" then
		T:go("R1F1D3R2F1L1")
		T:place("minecraft:redstone_torch", -1, "up", false)
		T:go("R1B1U3F1R1")
		T:place(userChoice, -1, "forward", false)
	end
end

function plantAutoTreeFarm()
	local blockType, blockModifier
	T:go("L1F4L1F1D3")
	while turtle.suckDown() do end
	T:go("L2U3F1R1F4L1")
	for  j = 1, 2 do
		for i = 1, 3 do
			blockType, blockModifier = T:getBlockType("forward")
			if  blockType == "minecraft:log" or blockType == "minecraft:log2" then
				T:harvestTree(true, false)
				T:forward(1)
			elseif  blockType == "minecraft:sapling" then
				T:go("U1F2D1")
			else
				T:go("U1F1")
				T:place("minecraft:sapling", -1, "down", false)
				T:go("F1D1")
			end
		end
		T:go("R1F3R1")
	end
	T:dropItem("minecraft:sapling", 0, "down")
	T:turnRight(2)
	T:dropItem("minecraft:log", 0, "forward")
	T:dropItem("minecraft:log2", 0, "forward")
	T:dropItem("minecraft:apple", 0, "forward")
	T:turnRight(2)
end

function harvestTreeFarm(size)
	local loopCount
	local blockType, blockModifier = T:getBlockType("forward") -- store information about the block in front in a table
	if size == 0 then --fell single tree
		blockType, blockModifier = T:getBlockType("forward") -- store information about the block in front in a table
		if blockType == "minecraft:log" or blockType == "minecraft:log2" then -- tree in front, so harvest it
			T:harvestTree(true, false)			
		end	
	else
		if size == 1 then
			loopCount = 4
		else
			loopCount = 8
		end
		if blockType == "minecraft:dirt" or blockType == "minecraft:grass" then
			T:up(1)
		end
		for i = 1, loopCount do
			harvestRun(loopCount * 2)
			turtle.turnRight()
			harvestRun(1)
			turtle.turnRight() --now facing opposite direction
			harvestRun(loopCount * 2)
			if i < loopCount then -- turn left if not on last run
				turtle.turnLeft()
				harvestRun(1)
				turtle.turnLeft()
			end
		end
		--return to starting position
		turtle.turnRight()
		harvestRun(loopCount * 2 - 1)
		turtle.turnRight()
	end
end

function harvestWheatFarm()
	T:forward(1)
	-- check if bucket or water bucket onboard
	--T:place(blockType, damageNo, direction, leaveExisting)
	T:place("minecraft:bucket", -1, "down", false)
	sleep(0.5)
	T:place("minecraft:bucket", -1, "down", false)
	-- assume 2x waterbuckets now onboard
	T:go("U1F9F2R1F8R2")
	for i = 1, 8 do
		T:place("minecraft:water_bucket", -1, "down", false)
		sleep(2)
		T:place("minecraft:bucket", -1, "down", false)
		if i > 1 then
			-- go back and repeat
			T:back(1)
			T:place("minecraft:water_bucket", -1, "down", false)
			sleep(2)
			T:place("minecraft:bucket", -1, "down", false)
			T:forward(1)
		end
		T:forward(1)
	end
	T:go("L1F9F3R2D1")
end

function plantWheatFarm()
	--player gets minecraft:wheat_seeds from hopper and are already onboard
	local turn =   {"F2U1F2R1F8L1F1L1","R1F1R1F1","L1F1L1F1","R1F1R1F1",
					"L1F1L1F1","R1F1R1F1","L1F1L1F1","R1F1R1F1"}
	local goHome = {"", "L1F3D1F2R2", "R1F3R1F9L1F1D1F2R2", "L1F5D1F3R2", "R1F5R1F9L1F1D1F2R2", "L1F7D1F2R2", "R1F7R1F9L1F1D1F2R2",
					"L1F9D1F2R2", "R1F9R1F9L1F1D1F2R2"}
	for i = 1, 9 do
		if T:getItemSlot("minecraft:wheat_seeds", 0) > 0 and i < 9 then -- min 8 seeds to get here
			T:go(turn[i])
			for j = 1, 8 do
				turtle.digDown()
				T:place("minecraft:wheat_seeds", 0, "down", false)
				T:forward(1)
			end
		else
			T:go(goHome[i])
			break
		end
	end
end

function plantTreefarm(size)
	-- .name = "minecraft:sapling"
	-- .state.type = "dark_oak"
	-- .metadata = 5
	local saplings = {"oak","spruce","birch","jungle","acacia","dark oak"}
	local slot = 0
	local quantity = 0
	local id = 0
	local most = 0
	local mostID = -1
	local secondMost = 0
	local secondMostID = -1
	
	for i = 0, 5 do
		slot, id, quantity = T:getItemSlot("minecraft:sapling", i) -- eg 3xoak, 9x spruce
		if slot > 0 then -- item found
			print(quantity.." "..saplings[i + 1].." found in slot "..slot)
			if quantity > most then -- this sapling quantity is > 0
				if most > 0 then -- another sapling already found, but quantity is greater
					secondMost = most
					secondMostID = mostID
					print("second sapling choice: "..saplings[secondMostID + 1])
				end
				most = quantity
				mostID = i
				print("first sapling choice: "..saplings[mostID + 1])
			else
				if most > 0 then
					secondMost = quantity
					secondMostID = i
				end
			end
		end
	end
	if secondMostID < 0 then
		secondMost = most
		secondMostID = mostID
		print("first and second sapling choice: "..saplings[secondMostID + 1])
	end
	
	local outerCount = 4
	local innerCount = 1
	local repeatCount = 1
	if size > 1 then
		outerCount = 8
		innerCount = 5
		repeatCount = 3
	end
	-- user may have put turtle on the ground
	if T:getBlockType("forward") == "minecraft:dirt" or T:getBlockType("forward") == "minecraft:grass" then
		T:up(1)
	end
	-- start at base of first tree LL corner
	T:go("U1F1")
	for x = 1, 4 do -- place most in a ring on outside of planting area
		for i = 1, outerCount do
			T:place("minecraft:sapling", mostID, "down", false)
			if i < outerCount then
				T:forward(1)
				T:place("minecraft:sapling", mostID, "down", false)
				T:forward(1)
			end
		end
		T:turnRight(1)
	end
	-- over first sapling, facing forward
	T:go("F2R1F2L1")
	-- place secondMost sapling in centre
	for x = 1, repeatCount do
		-- plant first column
		for i = 1, innerCount do
			if not T:place("minecraft:sapling", secondMostID, "down", false) then
				T:place("minecraft:sapling", mostID, "down", false)
			end
			if i < innerCount + 1 then
				T:forward(2)
				if not T:place("minecraft:sapling", secondMostID, "down", false) then
					T:place("minecraft:sapling", mostID, "down", false)
				end
			end
		end
		-- turn round and move to next column
		T:go("R1F2R1")
		-- plant return column
		for i = 1, innerCount do
			if not T:place("minecraft:sapling", secondMostID, "down", false) then
				T:place("minecraft:sapling", mostID, "down", false)
			end
			if i < innerCount + 1 then
				T:forward(2)
				if not T:place("minecraft:sapling", secondMostID, "down", false) then
					T:place("minecraft:sapling", mostID, "down", false)
				end
			end
		end
		if x < repeatCount then
			T:go("L1F2L1")
		end
	end
	if size == 1 then
		T:go("F1R1F3L1F2R1F1R1D2")
	else
		T:go("F1R1F9F2L1F2R1F1R1D2")
	end
end

function getMenu(options, numOptions)
	local errorNo = 0
	local choice = nil
	options = "Choose your option:\n"..options.."\nType number (q to quit) and Enter..."
	while choice == nil do
		T:clear()
		print(options)
		--term.write(options)
		term.setCursorPos(1, numOptions + 3)
		if errorNo == 1 then
			term.setCursorPos(1, 13)
			term.write("Incorrect input use numbers only")
			term.setCursorPos(1, numOptions + 3)
		elseif errorNo == 2 then
			term.setCursorPos(1, 13)
			term.write("Incorrect input use 1 to "..numOptions.." only")
			term.setCursorPos(1, numOptions + 3)
		end
		choice = read()
		if choice == "q" or choice == "Q" then
			choice = -1
		else
			choice = tonumber(choice)
		end
		if choice == nil then
			errorNo = 1	
		elseif choice < -1 or choice > numOptions then
			errorNo = 2	
			choice = nil
		end
	end
	return choice
end

function getDecision(choice)
	local decision = read()
	local retValue = 0
	if decision == "" or decision == "y" then -- allow for enter only
		retValue = choice
	end
	return tonumber(retValue)
end

function getSize(clear, prompt, lowerLimit, upperLimit)
	local retValue = -1
	while tonumber(retValue) < lowerLimit or  tonumber(retValue) > upperLimit do
		if clear then
			T:clear()
		end
		term.write(prompt)
		--io.write(prompt.."_")
		retValue = read()
		if tonumber(retValue) == nil then
			retValue = 0
		end
	end
	return tonumber(retValue)
end

function getTask()
	local choice = -1
	local size = 4
	local width = 0
	local length = 0
	local height = 0
	local menuOffset = 0 -- added to user choice
	local options = ""
	local mainChoice = 0
	while choice < 0 do
		options = 	"\t1) Mining tools\n"..
					"\t2) Tree management tools\n"..
					"\t3) Land management and farming tools\n"..
					"\t4) Obsidian and nether portal tools\n"..
					"\t5) Canal, bridge and walkway tools\n"..
					"\t6) Mob farm creation tools\n"..
					"\t7) Area carving tools\n"..
					"\t8) Lava and Water tools\n"..
					"\t9) Railway tools"
		mainChoice = getMenu(options , 9)
		
		if mainChoice < 0 then
			choice = -1
			break
		elseif mainChoice == 1 then
			options = 	"\t1) Create mine\n"..
						"\t2) Ladder to bedrock\n"..
						"\t3) Ladder to the surface\n"..
						"\t4) Stairs to bedrock\n"..
						"\t5) Stairs to the surface\n"..
						"\t6) Search for Mob Spawner\n"..
						"\t7) Decapitate volcano"
			choice = getMenu(options , 7)
			menuOffset = 10
		elseif mainChoice == 2 then
			options = 	"\t1) Clear Field\n"..
						"\t2) Create tree farm\n"..
						"\t3) Plant tree farm\n"..
						"\t4) Harvest tree farm\n"..
						"\t5) Fell Tree\n"..
						"\t6) Manage Auto-treeFarm"
			choice = getMenu(options , 6)
			menuOffset = 20
		elseif mainChoice == 3 then
			options = 	"\t1) Clear Field\n"..
						"\t2) Create 8x8 wheat farm\n"..
						"\t3) Plant 8x8 wheat farm\n"..
						"\t4) Harvest 8x8 wheat farm"
			choice = getMenu(options , 4)
			menuOffset = 30
		elseif mainChoice == 4 then
			options = 	"\t1) Dig obsidian patch\n"..
						"\t2) Build Nether Portal\n"..
						"\t3) Demolish Nether Portal"
			choice = getMenu(options , 3)
			menuOffset = 40
		elseif mainChoice == 5 then
			options = 	"\t1) Bridge over space or water\n"..
						"\t2) Covered walkway\n"..
						"\t3) Continuous single path\n"..
						"\t4) Left side canal (dry passageway)\n"..
						"\t5) Right side canal (flooded passage)"
			choice = getMenu(options , 5)
			menuOffset = 50
		elseif mainChoice == 6 then
			options = 	"\t1) Spawner base & ocean path\n"..
						"\t2) Create mob spawner tower\n"..
						"\t3) Create mob spawner chamber\n"..
						"\t4) Create mob spawner roof"
			choice = getMenu(options , 4)
			menuOffset = 60
		elseif mainChoice == 7 then
			options = 	"\t1) Clear a rectangle\n"..
						"\t2) Clear single wall\n"..
						"\t3) Clear rectangular wall section\n"..
						"\t4) Clear building floor and walls\n"..
						"\t5) Clear building floor/walls/ceiling\n"..
						"\t6) Hollow structure top->down\n"..
						"\t7) Solid structure top->down\n"..
						"\t8) Hollow structure bottom->up\n"..
						"\t9) Solid structure bottom->up"
			choice = getMenu(options , 9)
			menuOffset = 70
		elseif mainChoice == 8 then
			options = 	"\t1) Vertical wall from surface\n"..
						"\t2) Drop sand or gravel wall\n"..
						"\t3) Decapitate and fill with sand\n"..
						"\t4) Clear sand wall\n"..
						"\t5) Clear sand filled building\n"..
						"\t6) Demolish sand filled structure\n"..
						"\t7) Hollow structure top->down\n"..
						"\t8) Solid structure top->down"
			choice = getMenu(options , 8)
			menuOffset = 80
		elseif mainChoice == 9 then
			options = 	"\t1) Place Redstone:torch level track\n"..
						"\t2) Place Redstone:torch upward track\n"..
						"\t3) Build downward track\n"..
						"\t4) Build upward track"
			choice = getMenu(options , 4)
			menuOffset = 90
		end
		if choice >= 0 then
			choice = choice + menuOffset
		end
	end
	T:clear()
	local instructions = "Enter to continue\nany other key to quit"
	if choice == 11 then --Create Mine
		print(	"Press F3 to check level. Look for 'Z'\n"..
				"Place me down at   level 5, 9 or 13\n"..
				"(Equivalent to eye level 6, 10 or 14)\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 12 then -- Ladder to bedrock
		print(	"Place me on the ground\n"..
				"The ladder will start at this level\n"..
				"and drop to bedrock\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 13 then	-- Ladder to surface
		print(	"Place me on the ground\n"..
				"The ladder will start at this level\n"..
				"and rise to the surface\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 14 then -- Stairs to bedrock
		print(	"Place me on the ground\n"..
				"The stairs will start at this level\n"..
				"and drop to bedrock in a 5x5 block\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 15 then -- Stairs to surface
		print(	"Place me on the ground\n"..
				"The stairs will start at this level\n"..
				"and rise to level 64 in a 5x5 block\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 16 then -- Search for mob spawner
		print(	"Place me anywhere on the ground\n"..
				"When a spawner is found the\n"..
				"coordinates are saved to file\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 17 then -- Decapitate volcano
		print(	"Place me on a basalt block\n"..
				"on the left side of a volcano\n")
		width = getSize(false, "Volcano width at this level\n", 1, 64)
		length  = getSize(false, "Volcano length at this level\n", 1, 64)
	elseif choice == 21 or choice == 31 then --Clear field
		print(	"Place me on grass, lower left corner\n"..
				"of the area\n"..
				"To be levelled and cleared\n\n"..
				"Provide Dirt to plug voids in the floor\n")
		width = getSize(false, "Width of the area (1-64)\n", 1, 64)
		length  = getSize(false, "Length of the area (1-64)\n", 1, 64)
	elseif choice == 22 then --Create treefarm
		print(	"Place me on grass, lower left corner\n"..
				"of a 11x11 OR 19x19 square\n"..
				"Trees to be grown on alternate blocks\n"..
				"in a square 4x4 or 8x8 trees\n"..
				"with a 2 block wide margin\n"..
				instructions)
		choice = getDecision(choice)
		if choice > 0 then
			options = 	"\t1 - 4 x 4 trees(16)\n\t2 - 8 x 8 trees(64)"
			size = getMenu(options , 2)
		end
	elseif choice == 23 then --Replant treefarm
		print("Place me in front of first tree base\n"..
		"or dirt on the lower left corner\n"..
		"of a 4x4 trees OR 8x8 trees square\n\n"..
		"Provide Birch and Oak Saplings for a\n"..
		"mixed tree farm\n\n"..
		instructions)
		choice = getDecision(choice)
		if choice > 0 then
			options = 	"\t1 - 4 x 4 trees(16)\n\t2 - 8 x 8 trees(64)"
			size = getMenu(options , 2)
		end
	elseif choice == 24 then	-- Harvest treefarm
		print(	"Place me in front of first tree\n"..
				"on the lower left corner\n"..
				"of a 4x4 trees OR 8x8 trees square\n\n"..
				"Fuel not required as logs will be used.\n\n"..
				instructions)
		choice = getDecision(choice)
		if choice > 0 then
			options = 	"\t1 - 4 x 4 trees(16)\n\t2 - 8 x 8 trees(64)"
			size = getMenu(options , 2)
		end
	elseif choice == 25 then	-- Fell Tree
		print(	"Place me in front of the tree\n"..
				"you want to fell\n\n"..
				"Fuel not required as logs will be used.\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 26 then	-- Manage Auto-TreeFarm	
		print(	"For a new Auto-TreeFarm:\n"..
				"Place me on left side of a 13x10 area\n\n"..
				"For an existing farm:\n"..
				"Place me in front of sapling\n"..
				"or tree with the chest behind me\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 32 then	-- Create 8x8 wheat field farm
		print(	"Place me on left side of a cleared area\n"..
				"or rough land if you want to use\n"..
				"the option to clear the field first\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 33 then	-- Plant 8x8 wheat field
		print(	"Place me in front of the 2x2 pond\n"..
				"on the left side facing the\n"..
				"corner of the farm wall\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 34 then	-- Harvest 8x8 wheat field
		print(	"Place me in front of the 2x2 pond\n"..
				"on the left side facing the\n"..
				"corner of the farm wall\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 41 then	-- Harvest obsidian
		print(	"Place me on any block\n"..
				"on the left side facing the\n"..
				"obsidian patch.\n")
			width = getSize(false, "Width of the area (1-64)\n", 1, 64)
			length  = getSize(false, "Length of the area (1-64)\n", 1, 64)
	elseif choice == 42 then -- build Nether portal
		print(	"Place me on the ground\n"..
				"on the left side\n"..
				" of the portal base\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 43 then -- demolish Nether portal
		print(	"Place me on the ground\n"..
				"on the left side\n"..
				" of the portal base\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 51 then	--Bridge over void/water/lava
		print(	"Place me on the ground\n"..
				"The bridge will start in front,\n"..
				"continue for your chosen length\n"..
				"and return\n")
		size = getSize(false, "Length of the area (1-32)\n", 1, 32)
	elseif choice == 52 then	--Covered walkway
		print(	"Place me on the ground\n"..
				"The covered walkway will start in front,\n"..
				"continue for your chosen length\n"..
				"and return\n")
		size = getSize(false, "Length of the walk (1-32)\n", 1, 32)
	elseif choice == 53 then	--single path
		print(	"Place me on the ground in front\n"..
				"of water, lava or air.\n"..
				"Follow and supply blocks for a path\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 54 or choice == 55 then	--left/right side of new/existing canal
		local side = "left"
		if choice == 55 then
			side = "right"
		end
		print(	"I should be on either an existing canal\n"..
				"on the "..side.." side\n"..
				"or ready to start a new canal\n\n"..
				"If crossing water I should be on top\n"..
				"of a solid block making up the "..side.." wall\n")
		size = getSize(false, "Canal length? 0 = continuous\n", 0, 1024)
		length  = getSize(false, "Am I on the floor(0) or wall(1)?\n", 0, 1)
	elseif choice == 61 then -- Path to ocean base
		print(	"Place me on the ground in front\n"..
				"of the ocean.\n"..
				"Follow me as I create a path\n")
		size = getSize(false, "Path length (0-128)?\n", 0, 128)
	elseif choice == 62 then -- Ocean base complete. Place on polished block to start
		print(	"Place me on the stone block\n"..
				"(granite / andesite / diorite)\n"..
				"in the ocean base.\n"..
				"Facing the sea\n")
		size = getSize(false, "Tower Height (32-128)?\n", 32, 128)
	elseif choice == 63 then -- Mob tower complete Place on polished block to start
		print(	"Place me on the stone block\n"..
				"(granite / andesite / diorite)\n"..
				"at the top of the tower.\n"..
				"Facing the sea\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 64 then -- Mob tower roof Place on polished block to start
		print(	"Place me on the stone block\n"..
				"(granite / andesite / diorite)\n"..
				"at the top of the tower.\n"..
				"Facing the sea\n\n"..
				instructions)
		choice = getDecision(choice)
	elseif choice == 71 then -- Clear rectangle width, length
		print(	"Place me inside the lower left corner\n"..
				"of the rectangle to be cleared.\n"..
				"At the level to be worked on\n"..
				"I will include this corner in\n"..
				"the area to be cleared\n")
			width = getSize(false, "Width of the area (1-256)\n", 1, 256)
			length  = getSize(false, "Length of the area (1-256)\n", 1, 256)
	elseif choice == 72 then -- Clear wall height, length
		print(	"Place me inside the lower corner\n"..
				"of the wall to be cleared.\n")
			width = 1
			length = getSize(false, "Length of wall (1-256)\n", 1, 256)
			height = getSize(false, "Height of wall (1-50)\n", 1, 50)
	elseif choice == 73 then -- Clear rectangle perimeter only width, length
		print(	"Place me inside the left corner\n"..
				"of the rectangular wall to be cleared.\n"..
				"At the level to be worked on\n"..
				"I will include this corner in\n"..
				"the area to be cleared\n")
			width = getSize(false, "Width of walled area (1-256)\n", 1, 256)
			length  = getSize(false, "Length of walled area (1-256)\n", 1, 256)
			height = 1
	elseif choice == 74 then -- Clear building floor/walls
		print(	"Place me inside the left corner\n"..
				"in the floor of the building to be recycled.\n"..
				"At the level to be worked on\n"..
				"I will include this corner in\n"..
				"the area to be cleared\n")
			width = getSize(false, "Ext. building width (1-256)\n", 1, 256)
			length  = getSize(false, "Ext. building length (1-256)\n", 1, 256)
			height  = getSize(false, "Ext. building height (1-256)\n", 1, 256)
	elseif choice == 75 then -- Clear building floor/walls/ceiling
		print(	"Place me inside the lower left corner\n"..
				"in the floor of the building to be recycled.\n"..
				"At the level to be worked on\n"..
				"I will include this corner in\n"..
				"the area to be cleared\n")
			width = getSize(false, "Ext. building width (1-256)\n", 1, 256)
			length  = getSize(false, "Ext. building length (1-256)\n", 1, 256)
			height  = getSize(false, "Ext. building height (1-256)\n", 1, 256)
	elseif choice == 76 or choice == 87 then -- Hollow structure top down
		print(	"Place me inside the left corner\n"..
				"of the top of the hollow.\n")
			width = getSize(false, "Hollow section width (1-60)\n", 1, 60)
			length  = getSize(false, "Hollow section length (1-60)\n", 1, 60)
			height  = getSize(false, "Hollow section height (1-64)\n", 1, 64)
	elseif choice == 77 or choice == 88 then -- solid structure top down
		print(	"Place me inside the left corner\n"..
				"of the top of the cube.\n")
			width = getSize(false, "Solid section width (1-60)\n", 1, 60)
			length  = getSize(false, "Solid section length (1-60)\n", 1, 60)
			height  = getSize(false, "Solid section height (1-64)\n", 1, 64)
	elseif choice == 78 or choice == 79 then -- remove hollow/solid structure bottom up
		print(	"Place me inside the left corner\n"..
				"of the bottom of the structure.\n")
			width = getSize(false, "Structure width (1-60)\n", 1, 60)
			length  = getSize(false, "Structure length (1-60)\n", 1, 60)
			height  = getSize(false, "Structure height (1-64, 0=top)\n", 0, 64)
	elseif choice == 81 then -- build wall from water or lava surface downwards
		print(	"Place me on the surface facing wall END\n"..
				"(Any block below will be removed)\n"..
				"Wall will be built DOWN and BACKWARDS\n")
			width = 1
			length = getSize(false, "Length of the wall (1-60)\n", 1, 60)
			height = getSize(false, "Estimated depth (1-60) 0=default\n", 0, 60)
	elseif choice == 82 then -- drop sand into water or lava surface until solid grond reached
		print(	"Place me on the surface of water or lava\n"..
				"Sand  will be dropped DOWN and Forwards\n")
			width = 1
			length = getSize(false, "Length of dam (0=to solid block)\n", 0, 60)
	elseif choice == 83 then -- clear rectangle on top of building and fill with sand
		print(	"Place me on top left corner of roof\n"..
				"Sand  will be dropped into the hollow\n")
			width = getSize(false, "Width of roof (<=30)\n", 1, 30)
			length = getSize(false, "Length of of roof (<=30)\n", 1, 30)
	elseif choice == 84 then -- clear sand wall or harvest sand
		print(	"Place me on the surface of sand\n"..
				"Sand  will be mined DOWN then forwards\n")
			width = 1
			length = getSize(false, "Length of sand \n", 1, 250)
	elseif choice == 85 then -- remove sand from cube. start at top
		print(	"Place me on top left corner of sand\n"..
				"Sand cleared down, then left to right\n")
			width = getSize(false, "Width of sand (<=30)\n", 1, 30)
			length = getSize(false, "Length of of sand (<=30)\n", 1, 30)
	elseif choice == 86 then -- remove floor, walls (and sand) from building. start at base
		print(	"Place me on lower left corner of floor\n"..
				"Floor + walls removed + sand cleared\n")
			width = getSize(false, "Width of floor (<=30)\n", 1, 30)
			length = getSize(false, "Length of of floor (<=30)\n", 1, 30)
	-- elseif choice == 87 then check 76 above
	-- elseif choice == 88 then check 77 above
	elseif choice == 91 then -- place redstone torch under current block
		print(	"Place me on suspended railway stone\n"..
				"Redstone torch will go below me\n")
			width = 0
			length = 0
	elseif choice == 92 then -- place redstone torch on upward slope
		print(	"Place me on railway stone going up\n"..
				"Redstone torch will go below me\n")
			width = 0
			length = 0
	elseif choice == 93 then -- build downward slope
		print(	"Place me on last stone\n"..
				"Track will go down from this point\n")
			width = 0
			length = 0
			height  = getSize(false, "Drop down by how many blocks?\n", 1, 64)
	elseif choice == 94 then -- build upward slope
		print(	"Place me on last stone\n"..
				"Track will go up from this point\n")
			width = 0
			length = 0
			height  = getSize(false, "Go up by how many blocks?\n", 1, 64)
	end
	
	return choice, size, width, length, height -- eg 86, 0, 8, 8, 4
end

function initialise()
	local doContinue = true
	local hasChest = false
	print("Survival Toolkit")
	print()
	if os.getComputerLabel() == nil then
		os.setComputerLabel("Survivor")
		print("Computer label set to "..os.getComputerLabel())
		print()
		os.sleep(1.5)
	end
	-- create turtle object and check tools. Ideally crafting table and diamond pickaxe
	T = createTurtleObject()
	
	--[[ debug area!
		doContinue = false
		local block, blockType = T:isWaterOrLava("up")
		print("isWaterOrLava(up) = '"..block.."', "..blockType)
		block, blockType = T:isWaterOrLava("forward")
		print("isWaterOrLava(forward) = '"..block.."', "..blockType)
		block, blockType = T:isWaterOrLava("down")
		print("isWaterOrLava(down) = '"..block.."', "..blockType)]]
	
	--[[ debug area!
		--go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
		doContinue = false
		T:go("t0", true, 0, false, false)
		print("torch up")]]

	
	--T:getCoords(true)
	--home = createCoordinatesObject("homeLocation")
	--home:setAllValues(T:getX(), T:getY(), T:getZ(), T:getFacing())
	--make sure diamond pickaxe is equipped
	--[[while T.equippedLeft ~= "minecraft:diamond_pickaxe" do
		checkInventory(0, 0, 0, 0)
	end
	while T.equippedRight ~= "minecraft:crafting_table" do
		checkInventory(1, 0, 0, 0)
	end]]
	return doContinue
end

function repairWall(startAt, height, width, replaceWith)
	-- go up to startAt
	
	-- if width = 1
	
		-- for h = startAt, height, 1 do
		
			-- replace block with replaceWith ("" = any)
			
			-- move up
			
		--end
		
		-- move back to beginning
		
	-- else
	
		-- remain = height % 2
		
		-- for w = 1, width - remain do
		
			-- for h = startAt, height, 1 do
			
				-- replace block with replaceWith ("" = any)
				
				-- move up
				
			--end
			
			-- move to the right 1 block
			
			-- for i = height, startAt, -1 do
			
				-- replace block with replaceWith ("" = any)
				
				-- move down
				
			--end
			
		-- end
		
	-- end
	
end

function searchForSpawner(level)
	-- go down 8 with ladder above
	-- go(path, useTorch, torchInterval, leaveExisting, checkDungeon)
	-- depth = math.floor(level / 8)
	
	T:down(1)
	for i = 1, 6 do
		T:go("C1R1C1R1C1R1C1R1D1e0", false, 0, true, true)
	end
	-- go down 1 further
	T:down(1)
	
	local distance = 0
	local returnLength = 0
	local actualLength = 32
	local checkDungeon = true
	for j = 1, 4 do
		for i = 1, 3 do
			actualLength = 32
			actualLength = T:createTunnel(actualLength, true, checkDungeon) --may cut short if in ocean
			T:turnRight(1)
			T:createTunnel(9, false, checkDungeon)
			T:turnRight(1)
			T:createTunnel(actualLength, false)
			returnLength = returnLength + 8
			-- ready to cut next section
			if i < 3 then
				T:turnLeft(1)
				actualLength = T:createTunnel(9, true, checkDungeon) --may cut short if in ocean
				if actualLength == 9 then
					returnLength = returnLength + 8
					T:turnLeft(1)
				else
					-- cut short, block tunnel and return
					T:go("C2R1C1L1C1L1C1R1U1L1C1R1C1R1C1R1C0", false, 0, true, false)
					T:go("F"..actualLength.."D1", false, 0, true, true)
					break
				end
			else
				T:turnRight(1)
			end
			T:dumpRefuse(3) -- keep 4 stacks cobble
		end
		T:createTunnel(returnLength + 1, false, false)
		-- move 9 places forward and repeat
		T:createTunnel(9, false, checkDungeon)
	end
end

function main()
	if initialise() then
		-- crafting table equipped: continue
		local choice, size, width, length, height = getTask()
		if choice > 0 then
			checkInventory(choice, size, width, length, height)
		end	
		T:clear()
		print("Thank you for using 'survival toolkit'")
	else
		print("Unable to initialise. Check code")
	end
end

main()